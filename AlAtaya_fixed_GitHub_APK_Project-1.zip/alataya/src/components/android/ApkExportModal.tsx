import React, { useState } from 'react';
import {
  Smartphone,
  Download,
  Terminal,
  CheckCircle2,
  FolderArchive,
  Layers,
  FileCode,
  Sparkles,
} from 'lucide-react';
import { downloadAndroidNativeProjectZip } from '../../services/exportApk';
import { Modal } from '../common/Modal';

interface ApkExportModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const ApkExportModal: React.FC<ApkExportModalProps> = ({
  isOpen,
  onClose,
}) => {
  const [downloading, setDownloading] = useState(false);
  const [downloaded, setDownloaded] = useState(false);

  const handleDownload = async () => {
    setDownloading(true);
    try {
      await downloadAndroidNativeProjectZip();
      setDownloaded(true);
    } catch (e) {
      console.error(e);
      alert('حدث خطأ أثناء إعداد الحزمة');
    } finally {
      setDownloading(false);
    }
  };

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title="مشروع Android Native (Kotlin + Jetpack Compose)"
      subtitle="حزمة مشروع أندرويد متكاملة مع قاعدة بيانات Room Offline وجاهزة لتوليد APK"
      maxWidth="lg"
    >
      <div className="space-y-4 text-xs">
        {/* Banner */}
        <div className="p-3.5 bg-gradient-to-r from-emerald-50 to-teal-50 border border-emerald-200 rounded-xl flex items-start gap-3">
          <Smartphone className="w-6 h-6 text-emerald-600 shrink-0 mt-0.5" />
          <div className="space-y-1">
            <h4 className="font-black text-sm text-emerald-950">
              تطبيق أندرويد حقيقي يعمل 100% بدون إنترنت (Offline First)
            </h4>
            <p className="text-emerald-800 leading-relaxed">
              تم تجهيز الكود المصدري الأصلي بتقنية **Kotlin + Jetpack Compose** ومعمارية **Room Database (SQLite)**، بالإضافة إلى دعم الطابعات الحرارية عبر البلوتوث وتصميم RTL عربي بالكامل.
            </p>
          </div>
        </div>

        {/* Project Features Included */}
        <div className="space-y-2">
          <span className="font-bold text-slate-800 block">الملفات المضمنة في الحزمة:</span>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-[11px]">
            <div className="p-2.5 bg-slate-50 border border-slate-200 rounded-lg flex items-center gap-2">
              <FileCode className="w-4 h-4 text-purple-600 shrink-0" />
              <span>كيانات وقواعد بيانات Room SQLite</span>
            </div>
            <div className="p-2.5 bg-slate-50 border border-slate-200 rounded-lg flex items-center gap-2">
              <Layers className="w-4 h-4 text-blue-600 shrink-0" />
              <span>واجهات مستخدم كاملة بـ Jetpack Compose</span>
            </div>
            <div className="p-2.5 bg-slate-50 border border-slate-200 rounded-lg flex items-center gap-2">
              <FolderArchive className="w-4 h-4 text-amber-600 shrink-0" />
              <span>إعدادات Gradle KTS و AndroidManifest</span>
            </div>
            <div className="p-2.5 bg-slate-50 border border-slate-200 rounded-lg flex items-center gap-2">
              <Terminal className="w-4 h-4 text-emerald-600 shrink-0" />
              <span>أوامر بناء APK مباشر عبر السطر أو Studio</span>
            </div>
          </div>
        </div>

        {/* How to trigger build & download on GitHub */}
        <div className="p-3.5 bg-amber-500/10 rounded-2xl border border-amber-300/30 space-y-2 text-slate-800 dark:text-slate-200">
          <span className="font-black text-xs text-amber-700 dark:text-amber-400 block">
            كيف تعطي أمر البناء وتنزيل الـ APK من GitHub بضغطة زر:
          </span>
          <ol className="list-decimal list-inside space-y-1.5 text-[11px] leading-relaxed">
            <li>
              افتح صفحة الـ Actions في المستودع: <a href="https://github.com/abdallahkrata511-cyber/AlAtaya_Android_Native_Project-2-/actions" target="_blank" rel="noopener noreferrer" className="text-blue-600 underline font-bold">صفحة Actions</a>.
            </li>
            <li>
              اضغط على سير العمل من اليسار: <b>Build and Release Android APK</b>.
            </li>
            <li>
              اضغط على الزر الرمادي <b>Run workflow</b> ثم الزر الأخضر لتشغيل البناء.
            </li>
            <li>
              خلال دقيقتين ستجد ملف <b>alataya-distribution-apk</b> جاهزاً للتحميل، كما سيتم نشره في صفحة الإصدارات (Releases).
            </li>
          </ol>
        </div>

        {/* Action Buttons */}
        <div className="pt-2 space-y-2.5">
          <a
            href="https://github.com/abdallahkrata511-cyber/AlAtaya_Android_Native_Project-2-/actions/workflows/build-apk.yml"
            target="_blank"
            rel="noopener noreferrer"
            className="w-full py-3.5 bg-[#FFAA47] hover:bg-[#ff9f2c] text-slate-950 font-black rounded-2xl shadow-md transition active:scale-95 text-sm flex items-center justify-center gap-2 cursor-pointer font-display"
          >
            <Terminal className="w-5 h-5 stroke-[2.5]" />
            <span>تشغيل أمر البناء الآلي (Run Workflow في GitHub)</span>
          </a>

          <a
            href="https://github.com/abdallahkrata511-cyber/AlAtaya_Android_Native_Project-2-/releases"
            target="_blank"
            rel="noopener noreferrer"
            className="w-full py-3 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-2xl shadow-sm transition active:scale-95 text-xs flex items-center justify-center gap-2 cursor-pointer font-display"
          >
            <Download className="w-4 h-4" />
            <span>فتح صفحة التنزيل المباشر (Releases)</span>
          </a>

          <button
            type="button"
            onClick={handleDownload}
            disabled={downloading}
            className="w-full py-2.5 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-200 font-bold rounded-2xl transition active:scale-95 text-xs flex items-center justify-center gap-2 disabled:opacity-50 cursor-pointer font-display"
          >
            {downloading ? (
              <span>جاري ضغط ملفات المشروع...</span>
            ) : downloaded ? (
              <>
                <CheckCircle2 className="w-4 h-4 text-emerald-500" />
                <span>تم تنزيل المشروع بنجاح</span>
              </>
            ) : (
              <>
                <FolderArchive className="w-4 h-4 text-[#FFAA47]" />
                <span>تحميل المشروع كاملاً سورس كود (ZIP)</span>
              </>
            )}
          </button>
        </div>
      </div>
    </Modal>
  );
};
