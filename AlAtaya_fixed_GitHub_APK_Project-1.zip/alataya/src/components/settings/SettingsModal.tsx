import React, { useState, useRef } from 'react';
import {
  Settings,
  Save,
  Download,
  Upload,
  RotateCcw,
  Bluetooth,
  Store,
  FileCheck,
  Smartphone,
  Printer,
} from 'lucide-react';
import { AppSettings } from '../../types';
import { NumberInput } from '../common/NumberInput';
import { LocalDatabase } from '../../services/db';
import { Modal } from '../common/Modal';
import { BluetoothPrinterModal } from './BluetoothPrinterModal';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  settings: AppSettings;
  onSaveSettings: (settings: AppSettings) => void;
  onDataReload: () => void;
  onOpenApkModal: () => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  isOpen,
  onClose,
  settings,
  onSaveSettings,
  onDataReload,
  onOpenApkModal,
}) => {
  const [formData, setFormData] = useState<AppSettings>({ ...settings });
  const [backupMsg, setBackupMsg] = useState<string | null>(null);
  const [isBtModalOpen, setIsBtModalOpen] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    onSaveSettings(formData);
    onClose();
  };

  const handleExportBackup = () => {
    const jsonStr = LocalDatabase.exportBackup();
    const blob = new Blob([jsonStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `AlAtaya_Backup_${new Date().toISOString().slice(0, 10)}.json`;
    a.click();
    URL.revokeObjectURL(url);
    setBackupMsg('تم تصدير النسخة الاحتياطية بنجاح!');
    setTimeout(() => setBackupMsg(null), 3000);
  };

  const handleImportBackup = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const content = event.target?.result as string;
      const success = LocalDatabase.importBackup(content);
      if (success) {
        setBackupMsg('تم استرجاع النسخة الاحتياطية بنجاح!');
        onDataReload();
      } else {
        setBackupMsg('فشل استرجاع الملف، تأكد من صحة الملف');
      }
      setTimeout(() => setBackupMsg(null), 3500);
    };
    reader.readAsText(file);
  };

  const handleResetData = () => {
    if (
      confirm(
        'تحذير: هل أنت متأكد من إعادة تعيين جميع البيانات إلى البيانات الافتراضية الأولية؟'
      )
    ) {
      LocalDatabase.resetToDefault();
      onDataReload();
      onClose();
    }
  };

  return (
    <>
      <Modal
        isOpen={isOpen}
        onClose={onClose}
        title="إعدادات المركز وقاعدة البيانات"
        maxWidth="max-w-lg"
      >
        <form onSubmit={handleSave} className="space-y-4 text-slate-800 dark:text-slate-200">
          {/* Center Name */}
          <div>
            <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
              اسم المركز التجاري / الشركة
            </label>
            <input
              type="text"
              required
              value={formData.centerName}
              onChange={(e) => setFormData({ ...formData, centerName: e.target.value })}
              className="w-full h-11 px-3.5 bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl text-sm font-semibold focus:outline-hidden focus:border-blue-500"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            {/* Phone */}
            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                رقم الهاتف / واتساب
              </label>
              <input
                type="text"
                value={formData.centerPhone || ''}
                onChange={(e) => setFormData({ ...formData, centerPhone: e.target.value })}
                className="w-full h-11 px-3.5 bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl text-sm font-semibold focus:outline-hidden"
              />
            </div>

            {/* Address */}
            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                العنوان والمنطقة
              </label>
              <input
                type="text"
                value={formData.centerAddress || ''}
                onChange={(e) => setFormData({ ...formData, centerAddress: e.target.value })}
                className="w-full h-11 px-3.5 bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl text-sm font-semibold focus:outline-hidden"
              />
            </div>
          </div>

          {/* Exchange rate and currencies */}
          <div className="p-4 bg-slate-50/80 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 rounded-2xl space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-slate-800 dark:text-slate-200">
                سعر صرف الدولار المعتمد (ل.س):
              </span>
              <div className="w-36">
                <NumberInput
                  value={formData.exchangeRate}
                  onChange={(val) => setFormData({ ...formData, exchangeRate: Math.max(1, val) })}
                  min={1}
                  step={100}
                />
              </div>
            </div>

            {/* Partner & Capital Settings */}
            <div className="pt-2 border-t border-slate-200 dark:border-slate-700/80 space-y-2">
              <span className="text-xs font-bold text-purple-700 dark:text-purple-300 block">
                بيانات الشريك ورأس المال المودع:
              </span>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[11px] font-bold text-slate-600 dark:text-slate-400 mb-1">
                    اسم الشريك
                  </label>
                  <input
                    type="text"
                    value={formData.partnerName || ''}
                    onChange={(e) => setFormData({ ...formData, partnerName: e.target.value })}
                    placeholder="الشريك / أبو عمر"
                    className="w-full h-10 px-3 bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-xl text-xs font-semibold focus:outline-hidden"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-bold text-slate-600 dark:text-slate-400 mb-1">
                    رأس المال الأساسي ($)
                  </label>
                  <NumberInput
                    value={formData.partnerCapitalUSD || 5000}
                    onChange={(val) => setFormData({ ...formData, partnerCapitalUSD: val })}
                    min={0}
                    className="w-full h-10 px-3 bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-xl text-xs font-bold font-mono"
                  />
                </div>
              </div>
            </div>

            {/* Theme Mode Selection */}
            <div>
              <label className="block text-xs font-bold text-slate-800 dark:text-slate-200 mb-1.5">
                المظهر والوضع الليلي (Dark Mode)
              </label>
              <div className="grid grid-cols-3 gap-2 h-10 bg-slate-200/80 dark:bg-slate-700 p-1 rounded-xl">
                <button
                  type="button"
                  onClick={() => setFormData({ ...formData, themeMode: 'light' })}
                  className={`rounded-lg text-xs font-bold transition cursor-pointer ${
                    (formData.themeMode || 'light') === 'light'
                      ? 'bg-white text-slate-900 shadow-xs'
                      : 'text-slate-600 dark:text-slate-300'
                  }`}
                >
                  فاتح ☀️
                </button>
                <button
                  type="button"
                  onClick={() => setFormData({ ...formData, themeMode: 'dark' })}
                  className={`rounded-lg text-xs font-bold transition cursor-pointer ${
                    formData.themeMode === 'dark'
                      ? 'bg-slate-900 text-amber-300 shadow-xs'
                      : 'text-slate-600 dark:text-slate-300'
                  }`}
                >
                  ليلي 🌙
                </button>
                <button
                  type="button"
                  onClick={() => setFormData({ ...formData, themeMode: 'system' })}
                  className={`rounded-lg text-xs font-bold transition cursor-pointer ${
                    formData.themeMode === 'system'
                      ? 'bg-blue-600 text-white shadow-xs'
                      : 'text-slate-600 dark:text-slate-300'
                  }`}
                >
                  تلقائي ⚙️
                </button>
              </div>
            </div>
          </div>

          {/* Bluetooth printer dedicated manager button */}
          <div className="p-3.5 bg-blue-50/70 dark:bg-blue-950/30 border border-blue-200 dark:border-blue-900 rounded-2xl flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-blue-600 text-white flex items-center justify-center">
                <Bluetooth className="w-5 h-5" />
              </div>
              <div>
                <span className="text-xs font-bold text-blue-950 dark:text-blue-200 block">
                  طابعة البلوتوث الحرارية
                </span>
                <span className="text-[11px] text-blue-700 dark:text-blue-400">
                  إعدادات الربط، فحص الطباعة وعرض الورق (58mm/80mm)
                </span>
              </div>
            </div>
            <button
              type="button"
              onClick={() => setIsBtModalOpen(true)}
              className="px-3 py-2 bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold rounded-xl shadow-xs transition active:scale-95 cursor-pointer flex items-center gap-1"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>إدارة الطابعة</span>
            </button>
          </div>

          {/* Backup & Restore Local DB */}
          <div className="p-4 bg-slate-50 dark:bg-slate-800/40 border border-slate-200 dark:border-slate-800 rounded-2xl space-y-2">
            <span className="text-xs font-bold text-slate-800 dark:text-slate-200 block">
              النسخ الاحتياطي لقاعدة البيانات المحلية:
            </span>
            <p className="text-[11px] text-slate-500 dark:text-slate-400">
              احفظ نسخة كاملة من بياناتك (المنتجات، الفواتير، ديون العملاء والموردين) على هاتفك.
            </p>

            <div className="flex gap-2 pt-1">
              <button
                type="button"
                onClick={handleExportBackup}
                className="flex-1 py-2.5 px-3 bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 hover:bg-slate-100 text-slate-800 dark:text-slate-200 font-bold rounded-xl text-xs flex items-center justify-center gap-1.5 transition cursor-pointer"
              >
                <Download className="w-3.5 h-3.5" />
                <span>تصدير نسخة JSON</span>
              </button>

              <button
                type="button"
                onClick={() => fileInputRef.current?.click()}
                className="flex-1 py-2.5 px-3 bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 hover:bg-slate-100 text-slate-800 dark:text-slate-200 font-bold rounded-xl text-xs flex items-center justify-center gap-1.5 transition cursor-pointer"
              >
                <Upload className="w-3.5 h-3.5" />
                <span>استرجاع نسخة</span>
              </button>
              <input
                ref={fileInputRef}
                type="file"
                accept=".json"
                onChange={handleImportBackup}
                className="hidden"
              />
            </div>
            {backupMsg && (
              <p className="text-xs text-emerald-600 font-bold text-center mt-1 animate-pulse">
                {backupMsg}
              </p>
            )}
          </div>

          {/* Export APK shortcut button */}
          <div className="pt-1">
            <button
              type="button"
              onClick={() => {
                onClose();
                onOpenApkModal();
              }}
              className="w-full py-3 px-4 bg-slate-900 dark:bg-slate-800 hover:bg-black text-white font-bold rounded-xl text-xs flex items-center justify-center gap-2 transition cursor-pointer"
            >
              <Smartphone className="w-4 h-4 text-emerald-400" />
              <span>تعليمات وتصدير تطبيق Android APK الحقيقي</span>
            </button>
          </div>

          {/* Reset button */}
          <div className="pt-2 border-t border-slate-200 dark:border-slate-800 flex justify-between items-center">
            <button
              type="button"
              onClick={handleResetData}
              className="text-xs text-red-600 dark:text-red-400 hover:underline flex items-center gap-1 cursor-pointer"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>استعادة البيانات الافتراضية الأولية</span>
            </button>

            <button
              type="submit"
              className="py-2.5 px-5 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-xl text-xs flex items-center gap-1.5 shadow-xs transition active:scale-95 cursor-pointer"
            >
              <Save className="w-4 h-4" />
              <span>حفظ الإعدادات</span>
            </button>
          </div>
        </form>
      </Modal>

      {/* Dedicated Bluetooth Printer Modal */}
      <BluetoothPrinterModal
        isOpen={isBtModalOpen}
        onClose={() => setIsBtModalOpen(false)}
        centerName={formData.centerName}
      />
    </>
  );
};
