import {
  AppSettings,
  Currency,
  Product,
  Customer,
  Invoice,
  PurchaseInvoice,
  CustomerPayment,
  Supplier,
  SupplierTransaction,
  Expense,
  CashTransaction,
  UsdPurchase,
  GoodsWithdrawal,
  PartnerCapital,
  DailyInventoryAudit,
  InventoryItemBreakdown,
  ProjectReconciliation,
} from '../types';
import {
  initialSettings,
  initialProducts,
  initialCustomers,
  initialSuppliers,
  initialExpenses,
  initialInvoices,
  initialPurchaseInvoices,
  initialCustomerPayments,
  initialSupplierTransactions,
} from './seedData';
import { persistToSQLite } from './sqliteStore';

const STORAGE_KEYS = {
  SETTINGS: 'al_ataya_settings_v1',
  PRODUCTS: 'al_ataya_products_v1',
  CUSTOMERS: 'al_ataya_customers_v1',
  INVOICES: 'al_ataya_invoices_v1',
  PURCHASE_INVOICES: 'al_ataya_purchase_invoices_v1',
  CUSTOMER_PAYMENTS: 'al_ataya_customer_payments_v1',
  SUPPLIERS: 'al_ataya_suppliers_v1',
  SUPPLIER_TXS: 'al_ataya_supplier_txs_v1',
  EXPENSES: 'al_ataya_expenses_v1',
  CASH_TRANSACTIONS: 'al_ataya_cash_txs_v1',
  USD_PURCHASES: 'al_ataya_usd_purchases_v1',
  GOODS_WITHDRAWALS: 'al_ataya_goods_withdrawals_v1',
  PARTNER_CAPITAL: 'al_ataya_partner_capital_v1',
  DAILY_AUDITS: 'al_ataya_daily_audits_v1',
};

// Safe LocalStorage helpers with IndexedDB bridge
function loadItem<T>(key: string, fallback: T): T {
  try {
    const raw = localStorage.getItem(key);
    if (!raw) return fallback;
    return JSON.parse(raw);
  } catch (err) {
    console.error(`Error loading key ${key} from storage:`, err);
    return fallback;
  }
}

function saveItem<T>(key: string, data: T): void {
  try {
    localStorage.setItem(key, JSON.stringify(data));
    persistToSQLite(key, data);
  } catch (err) {
    console.error(`Error saving key ${key} to storage:`, err);
  }
}

export class LocalDatabase {
  // Settings
  static getSettings(): AppSettings {
    return loadItem<AppSettings>(STORAGE_KEYS.SETTINGS, initialSettings);
  }

  static saveSettings(settings: AppSettings): void {
    saveItem(STORAGE_KEYS.SETTINGS, settings);
  }

  // Products
  static getProducts(): Product[] {
    return loadItem<Product[]>(STORAGE_KEYS.PRODUCTS, initialProducts);
  }

  static saveProducts(products: Product[]): void {
    saveItem(STORAGE_KEYS.PRODUCTS, products);
  }

  static addProduct(product: Omit<Product, 'id' | 'createdAt' | 'updatedAt'>): Product {
    const products = this.getProducts();
    const newProduct: Product = {
      ...product,
      id: 'prod_' + Date.now() + '_' + Math.random().toString(36).substring(2, 6),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    products.unshift(newProduct);
    this.saveProducts(products);
    return newProduct;
  }

  static updateProduct(product: Product): void {
    const products = this.getProducts();
    const index = products.findIndex((p) => p.id === product.id);
    if (index !== -1) {
      products[index] = { ...product, updatedAt: new Date().toISOString() };
      this.saveProducts(products);
    }
  }

  static deleteProduct(productId: string): void {
    const products = this.getProducts().filter((p) => p.id !== productId);
    this.saveProducts(products);
  }

  // Adjust product stock directly (e.g. manual inventory correction or receiving shipment)
  static updateProductStock(productId: string, newTotalPieces: number): void {
    const products = this.getProducts();
    const product = products.find((p) => p.id === productId);
    if (product) {
      product.totalPiecesInStock = Math.max(0, newTotalPieces);
      product.updatedAt = new Date().toISOString();
      this.saveProducts(products);
    }
  }

  // Invoices
  static getInvoices(): Invoice[] {
    return loadItem<Invoice[]>(STORAGE_KEYS.INVOICES, initialInvoices);
  }

  static saveInvoices(invoices: Invoice[]): void {
    saveItem(STORAGE_KEYS.INVOICES, invoices);
  }

  // Create invoice and automatically deduct stock
  static createInvoice(invoiceData: Omit<Invoice, 'id' | 'createdAt' | 'updatedAt'>): Invoice {
    const invoices = this.getInvoices();
    const products = this.getProducts();

    // Deduct stock for each item in the invoice
    for (const item of invoiceData.items) {
      const product = products.find((p) => p.id === item.productId);
      if (product) {
        product.totalPiecesInStock = Math.max(0, product.totalPiecesInStock - item.totalPieces);
        product.updatedAt = new Date().toISOString();
      }
    }
    this.saveProducts(products);

    const newInvoice: Invoice = {
      ...invoiceData,
      id: 'inv_' + Date.now() + '_' + Math.random().toString(36).substring(2, 6),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    invoices.unshift(newInvoice);
    this.saveInvoices(invoices);
    return newInvoice;
  }

  // Edit invoice: restore previous items stock, deduct new items stock, update invoice
  static updateInvoice(updatedInvoice: Invoice): void {
    const invoices = this.getInvoices();
    const existingIndex = invoices.findIndex((i) => i.id === updatedInvoice.id);
    if (existingIndex === -1) return;

    const oldInvoice = invoices[existingIndex];
    const products = this.getProducts();

    // 1. Revert previous stock deduction
    for (const oldItem of oldInvoice.items) {
      const product = products.find((p) => p.id === oldItem.productId);
      if (product) {
        product.totalPiecesInStock += oldItem.totalPieces;
      }
    }

    // 2. Apply new stock deduction
    for (const newItem of updatedInvoice.items) {
      const product = products.find((p) => p.id === newItem.productId);
      if (product) {
        product.totalPiecesInStock = Math.max(0, product.totalPiecesInStock - newItem.totalPieces);
        product.updatedAt = new Date().toISOString();
      }
    }
    this.saveProducts(products);

    invoices[existingIndex] = {
      ...updatedInvoice,
      updatedAt: new Date().toISOString(),
    };
    this.saveInvoices(invoices);
  }

  // Delete invoice: restore inventory back to stock and remove invoice
  static deleteInvoice(invoiceId: string): void {
    const invoices = this.getInvoices();
    const targetInvoice = invoices.find((i) => i.id === invoiceId);
    if (!targetInvoice) return;

    // Restore stock
    const products = this.getProducts();
    for (const item of targetInvoice.items) {
      const product = products.find((p) => p.id === item.productId);
      if (product) {
        product.totalPiecesInStock += item.totalPieces;
        product.updatedAt = new Date().toISOString();
      }
    }
    this.saveProducts(products);

    const filtered = invoices.filter((i) => i.id !== invoiceId);
    this.saveInvoices(filtered);
  }

  // ================= Purchase Invoices (فواتير المشتريات) =================
  static getPurchaseInvoices(): PurchaseInvoice[] {
    return loadItem<PurchaseInvoice[]>(STORAGE_KEYS.PURCHASE_INVOICES, initialPurchaseInvoices);
  }

  static savePurchaseInvoices(invoices: PurchaseInvoice[]): void {
    saveItem(STORAGE_KEYS.PURCHASE_INVOICES, invoices);
  }

  static createPurchaseInvoice(
    invoiceData: Omit<PurchaseInvoice, 'id' | 'createdAt' | 'updatedAt'>
  ): PurchaseInvoice {
    const invoices = this.getPurchaseInvoices();
    const products = this.getProducts();

    const newInvoice: PurchaseInvoice = {
      ...invoiceData,
      id: 'pur_' + Date.now() + '_' + Math.random().toString(36).substring(2, 6),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    // 1. Automatically increase inventory stock for each purchased item
    // 2. Update product purchaseCost and costCurrency based on this latest purchase
    for (const item of newInvoice.items) {
      const product = products.find((p) => p.id === item.productId);
      if (product) {
        product.totalPiecesInStock += item.totalPieces;
        // Update purchase cost according to this latest purchase
        if (item.costPerCarton > 0) {
          product.purchaseCost = item.costPerCarton;
          product.costCurrency = newInvoice.currency;
        }
        product.updatedAt = new Date().toISOString();
      }
    }
    this.saveProducts(products);

    invoices.unshift(newInvoice);
    this.savePurchaseInvoices(invoices);
    return newInvoice;
  }

  static updatePurchaseInvoice(updatedInvoice: PurchaseInvoice): void {
    const invoices = this.getPurchaseInvoices();
    const oldIndex = invoices.findIndex((i) => i.id === updatedInvoice.id);
    if (oldIndex === -1) return;

    const oldInvoice = invoices[oldIndex];
    const products = this.getProducts();

    // 1. Revert previous stock quantities added by old invoice
    for (const oldItem of oldInvoice.items) {
      const product = products.find((p) => p.id === oldItem.productId);
      if (product) {
        product.totalPiecesInStock = Math.max(0, product.totalPiecesInStock - oldItem.totalPieces);
      }
    }

    // 2. Apply new stock quantities & update product cost to current values
    for (const newItem of updatedInvoice.items) {
      const product = products.find((p) => p.id === newItem.productId);
      if (product) {
        product.totalPiecesInStock += newItem.totalPieces;
        if (newItem.costPerCarton > 0) {
          product.purchaseCost = newItem.costPerCarton;
          product.costCurrency = updatedInvoice.currency;
        }
        product.updatedAt = new Date().toISOString();
      }
    }
    this.saveProducts(products);

    invoices[oldIndex] = {
      ...updatedInvoice,
      updatedAt: new Date().toISOString(),
    };
    this.savePurchaseInvoices(invoices);
  }

  static deletePurchaseInvoice(invoiceId: string): void {
    const invoices = this.getPurchaseInvoices();
    const target = invoices.find((i) => i.id === invoiceId);
    if (!target) return;

    const products = this.getProducts();

    // 1. Revert stock additions
    for (const item of target.items) {
      const product = products.find((p) => p.id === item.productId);
      if (product) {
        product.totalPiecesInStock = Math.max(0, product.totalPiecesInStock - item.totalPieces);
        product.updatedAt = new Date().toISOString();
      }
    }

    // 2. Filter out invoice
    const remainingInvoices = invoices.filter((i) => i.id !== invoiceId);

    // 3. For any product affected, check if there is an earlier purchase invoice to restore its previous cost
    for (const item of target.items) {
      const product = products.find((p) => p.id === item.productId);
      if (product) {
        // Find most recent purchase invoice for this product
        for (const pastInv of remainingInvoices) {
          const pastItem = pastInv.items.find((it) => it.productId === item.productId);
          if (pastItem && pastItem.costPerCarton > 0) {
            product.purchaseCost = pastItem.costPerCarton;
            product.costCurrency = pastInv.currency;
            break;
          }
        }
      }
    }

    this.saveProducts(products);
    this.savePurchaseInvoices(remainingInvoices);
  }

  // Customers
  static getCustomers(): Customer[] {
    return loadItem<Customer[]>(STORAGE_KEYS.CUSTOMERS, initialCustomers);
  }

  static saveCustomers(customers: Customer[]): void {
    saveItem(STORAGE_KEYS.CUSTOMERS, customers);
  }

  static addCustomer(customer: Omit<Customer, 'id' | 'createdAt'>): Customer {
    const customers = this.getCustomers();
    const newCustomer: Customer = {
      ...customer,
      id: 'cust_' + Date.now() + '_' + Math.random().toString(36).substring(2, 6),
      createdAt: new Date().toISOString(),
    };
    customers.push(newCustomer);
    this.saveCustomers(customers);
    return newCustomer;
  }

  static updateCustomer(customer: Customer): void {
    const customers = this.getCustomers();
    const index = customers.findIndex((c) => c.id === customer.id);
    if (index !== -1) {
      customers[index] = customer;
      this.saveCustomers(customers);
    }
  }

  static deleteCustomer(customerId: string): void {
    const customers = this.getCustomers().filter((c) => c.id !== customerId);
    this.saveCustomers(customers);
  }

  // Customer balance calculation:
  // Dual-currency balance: returns { syp: number, usd: number }
  static getCustomerDualBalance(customerId: string): { syp: number; usd: number } {
    const customers = this.getCustomers();
    const customer = customers.find((c) => c.id === customerId);
    if (!customer) return { syp: 0, usd: 0 };

    let syp = customer.currency === 'USD' ? 0 : (customer.initialDebt || 0);
    let usd = customer.currency === 'USD' ? (customer.initialDebt || 0) : (customer.initialDebtUSD || 0);

    const invoices = this.getInvoices().filter((inv) => inv.customerId === customerId);
    const payments = this.getCustomerPayments().filter((p) => p.customerId === customerId);

    for (const inv of invoices) {
      if (inv.isFixedUSD && inv.fixedUSDAmount) {
        // If fixed in USD, the unpaid portion remains as USD debt
        const paidUSD = inv.paidAmount > 0 ? (inv.currency === 'USD' ? inv.paidAmount : (inv.paidAmount / (inv.fixedExchangeRate || 1))) : 0;
        const remainingUSD = Math.max(0, inv.fixedUSDAmount - paidUSD);
        usd += remainingUSD;
      } else if (inv.currency === 'USD') {
        const remaining = Math.max(0, (inv.finalTotal || 0) - (inv.paidAmount || 0));
        usd += remaining;
      } else {
        const remaining = Math.max(0, (inv.finalTotal || 0) - (inv.paidAmount || 0));
        syp += remaining;
      }
    }

    for (const p of payments) {
      if (p.currency === 'USD') {
        usd -= (p.amount || 0);
      } else {
        syp -= (p.amount || 0);
      }
    }

    return { syp, usd };
  }

  // Legacy single customer balance for backward compatibility (in customer's primary currency or SYP)
  static getCustomerBalance(customerId: string): number {
    const dual = this.getCustomerDualBalance(customerId);
    const settings = this.getSettings();
    const rate = settings.exchangeRate || 15000;
    // Returns total value in SYP
    return dual.syp + (dual.usd * rate);
  }

  // Customer Payments
  static getCustomerPayments(): CustomerPayment[] {
    return loadItem<CustomerPayment[]>(STORAGE_KEYS.CUSTOMER_PAYMENTS, initialCustomerPayments);
  }

  static saveCustomerPayments(payments: CustomerPayment[]): void {
    saveItem(STORAGE_KEYS.CUSTOMER_PAYMENTS, payments);
  }

  static addCustomerPayment(payment: Omit<CustomerPayment, 'id' | 'createdAt'>): CustomerPayment {
    const payments = this.getCustomerPayments();
    const newPayment: CustomerPayment = {
      ...payment,
      id: 'pay_' + Date.now() + '_' + Math.random().toString(36).substring(2, 6),
      createdAt: new Date().toISOString(),
    };
    payments.unshift(newPayment);
    this.saveCustomerPayments(payments);
    return newPayment;
  }

  static updateCustomerPayment(payment: CustomerPayment): void {
    const payments = this.getCustomerPayments();
    const index = payments.findIndex((p) => p.id === payment.id);
    if (index !== -1) {
      payments[index] = payment;
      this.saveCustomerPayments(payments);
    }
  }

  static deleteCustomerPayment(paymentId: string): void {
    const payments = this.getCustomerPayments().filter((p) => p.id !== paymentId);
    this.saveCustomerPayments(payments);
  }

  // Suppliers
  static getSuppliers(): Supplier[] {
    return loadItem<Supplier[]>(STORAGE_KEYS.SUPPLIERS, initialSuppliers);
  }

  static saveSuppliers(suppliers: Supplier[]): void {
    saveItem(STORAGE_KEYS.SUPPLIERS, suppliers);
  }

  static addSupplier(supplier: Omit<Supplier, 'id' | 'createdAt'>): Supplier {
    const suppliers = this.getSuppliers();
    const newSupplier: Supplier = {
      ...supplier,
      id: 'supp_' + Date.now() + '_' + Math.random().toString(36).substring(2, 6),
      createdAt: new Date().toISOString(),
    };
    suppliers.push(newSupplier);
    this.saveSuppliers(suppliers);
    return newSupplier;
  }

  static updateSupplier(supplier: Supplier): void {
    const suppliers = this.getSuppliers();
    const index = suppliers.findIndex((s) => s.id === supplier.id);
    if (index !== -1) {
      suppliers[index] = supplier;
      this.saveSuppliers(suppliers);
    }
  }

  static deleteSupplier(supplierId: string): void {
    const suppliers = this.getSuppliers().filter((s) => s.id !== supplierId);
    this.saveSuppliers(suppliers);
  }

  // Supplier balance: Initial Debt + Purchase Invoices Total - Purchase Invoices Cash Paid + Manual Purchases - Manual Payments
  static getSupplierDualBalance(supplierId: string): { syp: number; usd: number } {
    const suppliers = this.getSuppliers();
    const supplier = suppliers.find((s) => s.id === supplierId);
    if (!supplier) return { syp: 0, usd: 0 };

    let syp = supplier.currency === 'USD' ? 0 : (supplier.initialDebt || 0);
    let usd = supplier.currency === 'USD' ? (supplier.initialDebt || 0) : (supplier.initialDebtUSD || 0);

    // 1. Purchase Invoices
    const purchaseInvoices = this.getPurchaseInvoices().filter((p) => p.supplierId === supplierId);
    for (const pur of purchaseInvoices) {
      const remaining = Math.max(0, (pur.finalTotal || 0) - (pur.paidAmount || 0));
      if (pur.currency === 'USD') {
        usd += remaining;
      } else {
        syp += remaining;
      }
    }

    // 2. Supplier manual ledger transactions
    const txs = this.getSupplierTransactions().filter((t) => t.supplierId === supplierId);
    for (const t of txs) {
      const sign = t.type === 'purchase' ? 1 : -1;
      if (t.currency === 'USD') {
        usd += sign * t.amount;
      } else {
        syp += sign * t.amount;
      }
    }

    return { syp, usd };
  }

  static getSupplierBalance(supplierId: string): number {
    const dual = this.getSupplierDualBalance(supplierId);
    const settings = this.getSettings();
    const rate = settings.exchangeRate || 15000;
    return dual.syp + (dual.usd * rate);
  }

  // Supplier Transactions
  static getSupplierTransactions(): SupplierTransaction[] {
    return loadItem<SupplierTransaction[]>(STORAGE_KEYS.SUPPLIER_TXS, initialSupplierTransactions);
  }

  static saveSupplierTransactions(txs: SupplierTransaction[]): void {
    saveItem(STORAGE_KEYS.SUPPLIER_TXS, txs);
  }

  static addSupplierTransaction(
    tx: Omit<SupplierTransaction, 'id' | 'createdAt'>
  ): SupplierTransaction {
    const txs = this.getSupplierTransactions();
    const newTx: SupplierTransaction = {
      ...tx,
      id: 'st_' + Date.now() + '_' + Math.random().toString(36).substring(2, 6),
      createdAt: new Date().toISOString(),
    };
    txs.unshift(newTx);
    this.saveSupplierTransactions(txs);
    return newTx;
  }

  static deleteSupplierTransaction(txId: string): void {
    const txs = this.getSupplierTransactions().filter((t) => t.id !== txId);
    this.saveSupplierTransactions(txs);
  }

  // Expenses
  static getExpenses(): Expense[] {
    const list = loadItem<Expense[]>(STORAGE_KEYS.EXPENSES, initialExpenses);
    let changed = false;
    const sanitized = list.map((e) => {
      if (e.person === 'أحمد' || e.person === 'محمد' || e.person === 'احمد') {
        changed = true;
        return { ...e, person: 'عبدالله' };
      }
      return e;
    });
    if (changed) {
      this.saveExpenses(sanitized);
    }
    return sanitized;
  }

  static saveExpenses(expenses: Expense[]): void {
    saveItem(STORAGE_KEYS.EXPENSES, expenses);
  }

  static addExpense(expense: Omit<Expense, 'id' | 'createdAt'>): Expense {
    const expenses = this.getExpenses();
    const newExpense: Expense = {
      ...expense,
      id: 'exp_' + Date.now() + '_' + Math.random().toString(36).substring(2, 6),
      createdAt: new Date().toISOString(),
    };
    expenses.unshift(newExpense);
    this.saveExpenses(expenses);
    return newExpense;
  }

  static deleteExpense(expenseId: string): void {
    const expenses = this.getExpenses().filter((e) => e.id !== expenseId);
    this.saveExpenses(expenses);
  }

  // Cash Transactions (Deposits, Abdallah/Partner Withdrawals, Special Expenses)
  static getCashTransactions(): CashTransaction[] {
    return loadItem<CashTransaction[]>(STORAGE_KEYS.CASH_TRANSACTIONS, []);
  }

  static saveCashTransactions(txs: CashTransaction[]): void {
    saveItem(STORAGE_KEYS.CASH_TRANSACTIONS, txs);
  }

  static addCashTransaction(
    tx: Omit<CashTransaction, 'id' | 'createdAt'>
  ): CashTransaction {
    const txs = this.getCashTransactions();
    const newTx: CashTransaction = {
      ...tx,
      id: 'cash_' + Date.now() + '_' + Math.random().toString(36).substring(2, 6),
      createdAt: new Date().toISOString(),
    };
    txs.unshift(newTx);
    this.saveCashTransactions(txs);
    return newTx;
  }

  static deleteCashTransaction(txId: string): void {
    const txs = this.getCashTransactions();
    const target = txs.find((t) => t.id === txId);
    if (target?.relatedEntityId && target.category === 'usd_purchase') {
      this.deleteUsdPurchase(target.relatedEntityId);
      return;
    }
    const filtered = txs.filter((t) => t.id !== txId);
    this.saveCashTransactions(filtered);
  }

  // USD Purchases (Buying USD with SYP from Cash Box)
  static getUsdPurchases(): UsdPurchase[] {
    return loadItem<UsdPurchase[]>(STORAGE_KEYS.USD_PURCHASES, []);
  }

  static saveUsdPurchases(purchases: UsdPurchase[]): void {
    saveItem(STORAGE_KEYS.USD_PURCHASES, purchases);
  }

  static addUsdPurchase(purchaseData: Omit<UsdPurchase, 'id' | 'createdAt'>): UsdPurchase {
    const purchases = this.getUsdPurchases();
    const newPurchase: UsdPurchase = {
      ...purchaseData,
      id: 'usdp_' + Date.now() + '_' + Math.random().toString(36).substring(2, 6),
      createdAt: new Date().toISOString(),
    };
    purchases.unshift(newPurchase);
    this.saveUsdPurchases(purchases);

    // Also automatically create the two mirrored cash transactions:
    // 1. SYP out (deduct costSYP)
    this.addCashTransaction({
      type: 'out',
      category: 'usd_purchase',
      title: `شراء دولار (${newPurchase.amountUSD.toLocaleString()} $ بسعر ${newPurchase.exchangeRate.toLocaleString()} ل.س)`,
      amount: newPurchase.costSYP,
      currency: 'SYP',
      date: newPurchase.date,
      person: 'عبدالله',
      notes: newPurchase.notes,
      relatedEntityId: newPurchase.id,
      exchangeRate: newPurchase.exchangeRate,
    });

    // 2. USD in (add amountUSD)
    this.addCashTransaction({
      type: 'in',
      category: 'usd_purchase',
      title: `إيداع دولار مشترى (${newPurchase.amountUSD.toLocaleString()} $)`,
      amount: newPurchase.amountUSD,
      currency: 'USD',
      date: newPurchase.date,
      person: 'عبدالله',
      notes: newPurchase.notes,
      relatedEntityId: newPurchase.id,
      exchangeRate: newPurchase.exchangeRate,
    });

    return newPurchase;
  }

  static updateUsdPurchase(updatedPurchase: UsdPurchase): void {
    // Delete existing mirrored cash transactions
    const cashTxs = this.getCashTransactions().filter((ctx) => ctx.relatedEntityId !== updatedPurchase.id);
    this.saveCashTransactions(cashTxs);

    // Update the purchase in list
    const purchases = this.getUsdPurchases().map((p) => (p.id === updatedPurchase.id ? updatedPurchase : p));
    this.saveUsdPurchases(purchases);

    // Re-create the two mirrored cash transactions
    this.addCashTransaction({
      type: 'out',
      category: 'usd_purchase',
      title: `شراء دولار (${updatedPurchase.amountUSD.toLocaleString()} $ بسعر ${updatedPurchase.exchangeRate.toLocaleString()} ل.س)`,
      amount: updatedPurchase.costSYP,
      currency: 'SYP',
      date: updatedPurchase.date,
      person: 'عبدالله',
      notes: updatedPurchase.notes,
      relatedEntityId: updatedPurchase.id,
      exchangeRate: updatedPurchase.exchangeRate,
    });

    this.addCashTransaction({
      type: 'in',
      category: 'usd_purchase',
      title: `إيداع دولار مشترى (${updatedPurchase.amountUSD.toLocaleString()} $)`,
      amount: updatedPurchase.amountUSD,
      currency: 'USD',
      date: updatedPurchase.date,
      person: 'عبدالله',
      notes: updatedPurchase.notes,
      relatedEntityId: updatedPurchase.id,
      exchangeRate: updatedPurchase.exchangeRate,
    });
  }

  static deleteUsdPurchase(id: string): void {
    const purchases = this.getUsdPurchases().filter((p) => p.id !== id);
    this.saveUsdPurchases(purchases);

    // Clean up mirrored cash transactions (reverts SYP and deducts USD)
    const cashTxs = this.getCashTransactions().filter((ctx) => ctx.relatedEntityId !== id);
    this.saveCashTransactions(cashTxs);
  }

  // Goods Withdrawals (Abdallah & Partner withdrawing products at cost)
  static getGoodsWithdrawals(): GoodsWithdrawal[] {
    return loadItem<GoodsWithdrawal[]>(STORAGE_KEYS.GOODS_WITHDRAWALS, []);
  }

  static saveGoodsWithdrawals(withdrawals: GoodsWithdrawal[]): void {
    saveItem(STORAGE_KEYS.GOODS_WITHDRAWALS, withdrawals);
  }

  static addGoodsWithdrawal(data: Omit<GoodsWithdrawal, 'id' | 'createdAt'>): GoodsWithdrawal {
    const withdrawals = this.getGoodsWithdrawals();
    const newWithdrawal: GoodsWithdrawal = {
      ...data,
      id: 'gw_' + Date.now() + '_' + Math.random().toString(36).substring(2, 6),
      createdAt: new Date().toISOString(),
    };

    // Deduct stock from inventory
    const products = this.getProducts();
    const product = products.find((p) => p.id === data.productId);
    if (product) {
      product.totalPiecesInStock = Math.max(0, product.totalPiecesInStock - data.totalPieces);
      product.updatedAt = new Date().toISOString();
      this.saveProducts(products);
    }

    withdrawals.unshift(newWithdrawal);
    this.saveGoodsWithdrawals(withdrawals);
    return newWithdrawal;
  }

  static deleteGoodsWithdrawal(id: string): void {
    const withdrawals = this.getGoodsWithdrawals();
    const target = withdrawals.find((w) => w.id === id);
    if (target) {
      // Revert stock
      const products = this.getProducts();
      const product = products.find((p) => p.id === target.productId);
      if (product) {
        product.totalPiecesInStock += target.totalPieces;
        product.updatedAt = new Date().toISOString();
        this.saveProducts(products);
      }
    }
    this.saveGoodsWithdrawals(withdrawals.filter((w) => w.id !== id));
  }

  // Partner Capital contributions
  static getPartnerCapitals(): PartnerCapital[] {
    const stored = loadItem<PartnerCapital[]>(STORAGE_KEYS.PARTNER_CAPITAL, []);
    if (stored.length === 0) {
      // Default initial capital 5000 USD as specified by user
      const defaultCap: PartnerCapital = {
        id: 'cap_initial_5000',
        partnerName: 'الشريك',
        amountUSD: 5000,
        date: '2026-03-01T00:00:00.000Z',
        notes: 'رأس مال الشريك الأساسي المتفق عليه (5,000 $)',
        createdAt: '2026-03-01T00:00:00.000Z',
      };
      return [defaultCap];
    }
    return stored;
  }

  static savePartnerCapitals(capitals: PartnerCapital[]): void {
    saveItem(STORAGE_KEYS.PARTNER_CAPITAL, capitals);
  }

  static addPartnerCapital(data: Omit<PartnerCapital, 'id' | 'createdAt'>): PartnerCapital {
    const list = this.getPartnerCapitals();
    const newCap: PartnerCapital = {
      ...data,
      id: 'cap_' + Date.now() + '_' + Math.random().toString(36).substring(2, 6),
      createdAt: new Date().toISOString(),
    };
    list.unshift(newCap);
    this.savePartnerCapitals(list);
    return newCap;
  }

  // Partner & Abdallah Account Balances calculation
  static getPartnerAccountSummary() {
    const settings = this.getSettings();
    const rate = settings.exchangeRate || 15000;
    const capitals = this.getPartnerCapitals();
    const totalCapitalUSD = capitals.reduce((sum, c) => sum + (c.amountUSD || 0), 0);

    const cashTxs = this.getCashTransactions();
    const goodsWithdrawals = this.getGoodsWithdrawals();

    // Partner Cash Withdrawals
    let partnerCashSYP = 0;
    let partnerCashUSD = 0;
    // Abdallah Cash Withdrawals
    let abdallahCashSYP = 0;
    let abdallahCashUSD = 0;

    for (const ctx of cashTxs) {
      if (ctx.type === 'out') {
        if (ctx.category === 'partner_withdrawal' || ctx.person === (settings.partnerName || 'الشريك')) {
          if (ctx.currency === 'USD') partnerCashUSD += ctx.amount;
          else partnerCashSYP += ctx.amount;
        } else if (ctx.category === 'abdallah_withdrawal' || ctx.person === 'عبدالله') {
          if (ctx.currency === 'USD') abdallahCashUSD += ctx.amount;
          else abdallahCashSYP += ctx.amount;
        }
      }
    }

    // Goods Withdrawals
    let partnerGoodsSYP = 0;
    let partnerGoodsUSD = 0;
    let abdallahGoodsSYP = 0;
    let abdallahGoodsUSD = 0;

    for (const gw of goodsWithdrawals) {
      if (gw.person === 'partner') {
        if (gw.currency === 'USD') partnerGoodsUSD += gw.totalCost;
        else partnerGoodsSYP += gw.totalCost;
      } else {
        if (gw.currency === 'USD') abdallahGoodsUSD += gw.totalCost;
        else abdallahGoodsSYP += gw.totalCost;
      }
    }

    // Totals in USD equivalent
    const partnerTotalWithdrawnUSD = partnerCashUSD + (partnerCashSYP / rate) + partnerGoodsUSD + (partnerGoodsSYP / rate);
    const abdallahTotalWithdrawnUSD = abdallahCashUSD + (abdallahCashSYP / rate) + abdallahGoodsUSD + (abdallahGoodsSYP / rate);

    return {
      partnerName: settings.partnerName || 'الشريك',
      totalCapitalUSD,
      partnerCashSYP,
      partnerCashUSD,
      partnerGoodsSYP,
      partnerGoodsUSD,
      partnerTotalWithdrawnUSD,
      abdallahCashSYP,
      abdallahCashUSD,
      abdallahGoodsSYP,
      abdallahGoodsUSD,
      abdallahTotalWithdrawnUSD,
    };
  }

  // Unified Cash Box Ledger Items
  static getCashBoxUnifiedLedger(): Array<{
    id: string;
    source: 'sale' | 'customer_payment' | 'purchase' | 'supplier_payment' | 'expense' | 'cash_tx';
    type: 'in' | 'out';
    category: string;
    title: string;
    amount: number;
    currency: Currency;
    date: string;
    person?: string;
    notes?: string;
  }> {
    const list: Array<{
      id: string;
      source: 'sale' | 'customer_payment' | 'purchase' | 'supplier_payment' | 'expense' | 'cash_tx';
      type: 'in' | 'out';
      category: string;
      title: string;
      amount: number;
      currency: Currency;
      date: string;
      person?: string;
      notes?: string;
    }> = [];

    // 1. Sales Invoices Cash Paid
    const invoices = this.getInvoices();
    for (const inv of invoices) {
      if (inv.paidAmount > 0) {
        list.push({
          id: 'cash_inv_' + inv.id,
          source: 'sale',
          type: 'in',
          category: 'مبيعات نقدية',
          title: `مقبوضات فاتورة بيع ${inv.invoiceNumber} (${inv.customerName})`,
          amount: inv.paidAmount,
          currency: inv.currency,
          date: inv.date || inv.createdAt,
          person: inv.customerName,
          notes: inv.notes,
        });
      }
    }

    // 2. Customer Debt Payments
    const custPayments = this.getCustomerPayments();
    for (const cp of custPayments) {
      if (cp.amount > 0) {
        list.push({
          id: 'cash_cp_' + cp.id,
          source: 'customer_payment',
          type: 'in',
          category: 'دفعة عميل',
          title: `سداد دفعة حساب - العميل ${cp.customerName}`,
          amount: cp.amount,
          currency: cp.currency,
          date: cp.date || cp.createdAt,
          person: cp.customerName,
          notes: cp.notes,
        });
      }
    }

    // 3. Purchase Invoices Cash Paid
    const purchases = this.getPurchaseInvoices();
    for (const pur of purchases) {
      if (pur.paidAmount > 0) {
        list.push({
          id: 'cash_pur_' + pur.id,
          source: 'purchase',
          type: 'out',
          category: 'مشتريات نقدية',
          title: `مدفوعات فاتورة شراء ${pur.invoiceNumber} (${pur.supplierName})`,
          amount: pur.paidAmount,
          currency: pur.currency,
          date: pur.date || pur.createdAt,
          person: pur.supplierName,
          notes: pur.notes,
        });
      }
    }

    // 4. Supplier Debt Payments (from ledger)
    const suppTxs = this.getSupplierTransactions();
    for (const st of suppTxs) {
      if (st.type === 'payment' && st.amount > 0) {
        list.push({
          id: 'cash_st_' + st.id,
          source: 'supplier_payment',
          type: 'out',
          category: 'دفعة مورد',
          title: `سداد دفعة حساب - المورد ${st.supplierName}`,
          amount: st.amount,
          currency: st.currency,
          date: st.date || st.createdAt,
          person: st.supplierName,
          notes: st.notes,
        });
      }
    }

    // 5. Operating Expenses
    const expenses = this.getExpenses();
    for (const exp of expenses) {
      if (exp.amount > 0) {
        list.push({
          id: 'cash_exp_' + exp.id,
          source: 'expense',
          type: 'out',
          category: exp.category || 'مصاريف تشغيلية',
          title: `مصروف: ${exp.category}`,
          amount: exp.amount,
          currency: exp.currency,
          date: exp.date || exp.createdAt,
          person: exp.person,
          notes: exp.notes,
        });
      }
    }

    // 6. Manual Cash Transactions (Deposits, Abdallah/Partner Withdrawals, Special Expenses)
    const cashTxs = this.getCashTransactions();
    for (const ctx of cashTxs) {
      let catLabel = 'حركة نقدية';
      if (ctx.category === 'usd_purchase') catLabel = 'شراء دولار نقدي';
      else if (ctx.category === 'usd_sale') catLabel = 'بيع دولار نقدي';
      else if (ctx.category === 'abdallah_withdrawal') catLabel = 'سحب عبدالله';
      else if (ctx.category === 'partner_withdrawal') catLabel = 'سحب الشريك';
      else if (ctx.category === 'special_expense') catLabel = 'مصروف خاص';
      else if (ctx.category === 'capital_deposit') catLabel = 'إيداع نقدي / رأس مال';
      else if (ctx.type === 'in') catLabel = 'إيداع بالصندوق';
      else catLabel = 'سحب نقدي';

      list.push({
        id: 'cash_ctx_' + ctx.id,
        source: 'cash_tx',
        type: ctx.type,
        category: catLabel,
        title: ctx.title,
        amount: ctx.amount,
        currency: ctx.currency,
        date: ctx.date || ctx.createdAt,
        person: ctx.person,
        notes: ctx.notes,
      });
    }

    // Sort newest date first
    return list.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
  }

  // Cash Box Summary & Balances
  static getCashBoxSummary() {
    const settings = this.getSettings();
    const rate = settings.exchangeRate || 15000;
    const ledger = this.getCashBoxUnifiedLedger();

    const initialCashSYP = settings.initialCashSYP || 0;
    const initialCashUSD = settings.initialCashUSD || 0;

    let inSYP = 0;
    let inUSD = 0;
    let outSYP = 0;
    let outUSD = 0;

    let salesInSYP = 0;
    let salesInUSD = 0;
    let custPaymentsInSYP = 0;
    let custPaymentsInUSD = 0;

    let purchasesOutSYP = 0;
    let purchasesOutUSD = 0;
    let supplierPaymentsOutSYP = 0;
    let supplierPaymentsOutUSD = 0;
    let operatingExpensesOutSYP = 0;
    let operatingExpensesOutUSD = 0;

    let abdallahWithdrawalsSYP = 0;
    let abdallahWithdrawalsUSD = 0;
    let partnerWithdrawalsSYP = 0;
    let partnerWithdrawalsUSD = 0;
    let specialExpensesSYP = 0;
    let specialExpensesUSD = 0;

    for (const item of ledger) {
      if (item.type === 'in') {
        if (item.currency === 'USD') inUSD += item.amount;
        else inSYP += item.amount;

        if (item.source === 'sale') {
          if (item.currency === 'USD') salesInUSD += item.amount;
          else salesInSYP += item.amount;
        } else if (item.source === 'customer_payment') {
          if (item.currency === 'USD') custPaymentsInUSD += item.amount;
          else custPaymentsInSYP += item.amount;
        }
      } else {
        if (item.currency === 'USD') outUSD += item.amount;
        else outSYP += item.amount;

        if (item.source === 'purchase') {
          if (item.currency === 'USD') purchasesOutUSD += item.amount;
          else purchasesOutSYP += item.amount;
        } else if (item.source === 'supplier_payment') {
          if (item.currency === 'USD') supplierPaymentsOutUSD += item.amount;
          else supplierPaymentsOutSYP += item.amount;
        } else if (item.source === 'expense') {
          if (item.currency === 'USD') operatingExpensesOutUSD += item.amount;
          else operatingExpensesOutSYP += item.amount;
        } else if (item.source === 'cash_tx') {
          if (item.category === 'سحب عبدالله') {
            if (item.currency === 'USD') abdallahWithdrawalsUSD += item.amount;
            else abdallahWithdrawalsSYP += item.amount;
          } else if (item.category === 'سحب الشريك') {
            if (item.currency === 'USD') partnerWithdrawalsUSD += item.amount;
            else partnerWithdrawalsSYP += item.amount;
          } else if (item.category === 'مصروف خاص') {
            if (item.currency === 'USD') specialExpensesUSD += item.amount;
            else specialExpensesSYP += item.amount;
          }
        }
      }
    }

    const expectedCashSYP = initialCashSYP + inSYP - outSYP;
    const expectedCashUSD = initialCashUSD + inUSD - outUSD;

    // Combined total in SYP
    const combinedTotalSYP = expectedCashSYP + expectedCashUSD * rate;

    return {
      initialCashSYP,
      initialCashUSD,
      inSYP,
      inUSD,
      outSYP,
      outUSD,
      expectedCashSYP,
      expectedCashUSD,
      combinedTotalSYP,
      salesInSYP,
      salesInUSD,
      custPaymentsInSYP,
      custPaymentsInUSD,
      purchasesOutSYP,
      purchasesOutUSD,
      supplierPaymentsOutSYP,
      supplierPaymentsOutUSD,
      operatingExpensesOutSYP,
      operatingExpensesOutUSD,
      abdallahWithdrawalsSYP,
      abdallahWithdrawalsUSD,
      partnerWithdrawalsSYP,
      partnerWithdrawalsUSD,
      specialExpensesSYP,
      specialExpensesUSD,
    };
  }

  // Overall Financial Summary
  static getFinancialSummary(): {
    totalSales: number;
    totalPurchases: number;
    totalCashReceived: number;
    totalCustomerDebt: number;
    totalSupplierDebt: number;
    totalExpenses: number;
    netCashBalance: number;
    totalInventoryValueSYP: number;
  } {
    const settings = this.getSettings();
    const rate = settings.exchangeRate || 15000;

    const invoices = this.getInvoices();
    const purchaseInvoices = this.getPurchaseInvoices();
    const customers = this.getCustomers();
    const suppliers = this.getSuppliers();
    const products = this.getProducts();
    const cashSummary = this.getCashBoxSummary();

    // Invoices sales total
    let totalSales = 0;
    for (const inv of invoices) {
      const multiplier = inv.currency === 'USD' ? rate : 1;
      totalSales += inv.finalTotal * multiplier;
    }

    // Purchase invoices total
    let totalPurchases = 0;
    for (const pur of purchaseInvoices) {
      const multiplier = pur.currency === 'USD' ? rate : 1;
      totalPurchases += pur.finalTotal * multiplier;
    }

    // Total Customer Debt (sum of each customer's balance)
    let totalCustomerDebt = 0;
    for (const cust of customers) {
      const balance = this.getCustomerBalance(cust.id);
      const multiplier = cust.currency === 'USD' ? rate : 1;
      totalCustomerDebt += balance * multiplier;
    }

    // Total Supplier Debt
    let totalSupplierDebt = 0;
    for (const supp of suppliers) {
      const balance = this.getSupplierBalance(supp.id);
      const multiplier = supp.currency === 'USD' ? rate : 1;
      totalSupplierDebt += balance * multiplier;
    }

    // Total inventory value
    let totalInventoryValueSYP = 0;
    for (const prod of products) {
      const cartonCostSYP = prod.costCurrency === 'USD' ? prod.purchaseCost * rate : prod.purchaseCost;
      const pieceCostSYP = cartonCostSYP / (prod.piecesPerCarton || 1);
      totalInventoryValueSYP += prod.totalPiecesInStock * pieceCostSYP;
    }

    const totalCashReceived = cashSummary.inSYP + cashSummary.inUSD * rate;
    const totalExpenses =
      cashSummary.operatingExpensesOutSYP +
      cashSummary.operatingExpensesOutUSD * rate +
      cashSummary.specialExpensesSYP +
      cashSummary.specialExpensesUSD * rate;

    const netCashBalance = cashSummary.combinedTotalSYP;

    return {
      totalSales,
      totalPurchases,
      totalCashReceived,
      totalCustomerDebt,
      totalSupplierDebt,
      totalExpenses,
      netCashBalance,
      totalInventoryValueSYP,
    };
  }

  // Comprehensive Daily Inventory (Jard) Calculation
  static getDailyInventoryAudit(customRate?: number, asOfDate?: string): DailyInventoryAudit {
    const settings = this.getSettings();
    const rate = customRate || settings.exchangeRate || 15000;
    const filterDate = asOfDate ? asOfDate + 'T23:59:59.999Z' : null;

    // Helper to check if record is on or before asOfDate
    const isBeforeDate = (dateStr?: string) => {
      if (!filterDate || !dateStr) return true;
      return new Date(dateStr).getTime() <= new Date(filterDate).getTime();
    };

    // 1. Cash Balances (Calculate from ledger transactions up to asOfDate)
    let cashSYP = settings.initialCashSYP || 0;
    let cashUSD = settings.initialCashUSD || 0;

    const fullLedger = this.getCashBoxUnifiedLedger();
    for (const item of fullLedger) {
      if (!isBeforeDate(item.date)) continue;
      if (item.type === 'in') {
        if (item.currency === 'USD') cashUSD += item.amount;
        else cashSYP += item.amount;
      } else {
        if (item.currency === 'USD') cashUSD -= item.amount;
        else cashSYP -= item.amount;
      }
    }

    // 2. Customers Debt Breakdown (Dual-Currency) up to asOfDate
    const customers = this.getCustomers();
    let customerDebtSYP = 0;
    let customerDebtUSD = 0;
    const customerDebtsList: Array<{
      id: string;
      name: string;
      shopName?: string;
      syp: number;
      usd: number;
      totalInUSD: number;
    }> = [];

    for (const cust of customers) {
      let syp = cust.currency === 'USD' ? 0 : (cust.initialDebt || 0);
      let usd = cust.currency === 'USD' ? (cust.initialDebt || 0) : (cust.initialDebtUSD || 0);

      // Invoices
      const custInvoices = this.getInvoices().filter((inv) => inv.customerId === cust.id && isBeforeDate(inv.date));
      for (const inv of custInvoices) {
        if (inv.isFixedUSD && inv.fixedUSDAmount) {
          const paidUSD = (inv.paidAmount || 0) / (inv.fixedExchangeRate || inv.exchangeRate || rate);
          usd += Math.max(0, inv.fixedUSDAmount - paidUSD);
        } else if (inv.currency === 'USD') {
          usd += Math.max(0, (inv.finalTotal || 0) - (inv.paidAmount || 0));
        } else {
          syp += Math.max(0, (inv.finalTotal || 0) - (inv.paidAmount || 0));
        }
      }

      // Payments
      const custPayments = this.getCustomerPayments().filter((p) => p.customerId === cust.id && isBeforeDate(p.date));
      for (const p of custPayments) {
        if (p.currency === 'USD') {
          usd -= p.amount;
        } else {
          syp -= p.amount;
        }
      }

      if (syp !== 0 || usd !== 0) {
        customerDebtSYP += syp;
        customerDebtUSD += usd;
        customerDebtsList.push({
          id: cust.id,
          name: cust.name,
          shopName: cust.shopName,
          syp,
          usd,
          totalInUSD: usd + (syp / rate),
        });
      }
    }

    // 3. Suppliers Debt Breakdown (Dual-Currency) up to asOfDate
    const suppliers = this.getSuppliers();
    let supplierDebtSYP = 0;
    let supplierDebtUSD = 0;
    const supplierDebtsList: Array<{
      id: string;
      name: string;
      company?: string;
      syp: number;
      usd: number;
      totalInUSD: number;
    }> = [];

    for (const supp of suppliers) {
      let syp = supp.currency === 'USD' ? 0 : (supp.initialDebt || 0);
      let usd = supp.currency === 'USD' ? (supp.initialDebt || 0) : (supp.initialDebtUSD || 0);

      const purchaseInvoices = this.getPurchaseInvoices().filter((p) => p.supplierId === supp.id && isBeforeDate(p.date));
      for (const pur of purchaseInvoices) {
        const remaining = Math.max(0, (pur.finalTotal || 0) - (pur.paidAmount || 0));
        if (pur.currency === 'USD') usd += remaining;
        else syp += remaining;
      }

      const txs = this.getSupplierTransactions().filter((t) => t.supplierId === supp.id && isBeforeDate(t.date));
      for (const t of txs) {
        const sign = t.type === 'purchase' ? 1 : -1;
        if (t.currency === 'USD') usd += sign * t.amount;
        else syp += sign * t.amount;
      }

      if (syp !== 0 || usd !== 0) {
        supplierDebtSYP += syp;
        supplierDebtUSD += usd;
        supplierDebtsList.push({
          id: supp.id,
          name: supp.name,
          company: supp.company,
          syp,
          usd,
          totalInUSD: usd + (syp / rate),
        });
      }
    }

    // 4. Warehouse Inventory Value at Cost (Classified by SYP & USD)
    const products = this.getProducts().filter((p) => !p.isArchived);
    let inventoryCostUSD = 0;
    let inventoryCostSYP = 0;
    let totalPiecesCount = 0;

    const inventorySYPItems: InventoryItemBreakdown[] = [];
    const inventoryUSDItems: InventoryItemBreakdown[] = [];

    for (const prod of products) {
      totalPiecesCount += prod.totalPiecesInStock;
      const ppc = prod.piecesPerCarton || 1;
      const cartons = Math.floor(prod.totalPiecesInStock / ppc);
      const loosePieces = prod.totalPiecesInStock % ppc;
      const cartonsEquivalent = prod.totalPiecesInStock / ppc;
      const pieceCost = prod.purchaseCost / ppc;
      const totalCostOriginal = cartonsEquivalent * prod.purchaseCost;

      if (prod.costCurrency === 'USD') {
        inventoryCostUSD += totalCostOriginal;
        inventoryUSDItems.push({
          id: prod.id,
          name: prod.name,
          unit: prod.unit || 'كرتونة',
          piecesPerCarton: ppc,
          totalPieces: prod.totalPiecesInStock,
          cartons,
          loosePieces,
          costCurrency: 'USD',
          unitCost: prod.purchaseCost,
          pieceCost,
          totalCostOriginal,
          equivalentUSD: totalCostOriginal,
          equivalentSYP: totalCostOriginal * rate,
        });
      } else {
        inventoryCostSYP += totalCostOriginal;
        inventorySYPItems.push({
          id: prod.id,
          name: prod.name,
          unit: prod.unit || 'كرتونة',
          piecesPerCarton: ppc,
          totalPieces: prod.totalPiecesInStock,
          cartons,
          loosePieces,
          costCurrency: 'SYP',
          unitCost: prod.purchaseCost,
          pieceCost,
          totalCostOriginal,
          equivalentUSD: totalCostOriginal / rate,
          equivalentSYP: totalCostOriginal,
        });
      }
    }

    // Total Inventory unified in USD & SYP
    const totalInventoryInUSD = inventoryCostUSD + (inventoryCostSYP / rate);
    const totalInventoryInSYP = (inventoryCostUSD * rate) + inventoryCostSYP;

    // 5. Partners & Capital (Up to asOfDate)
    const rawPartnerSummary = this.getPartnerAccountSummary();
    let partnerCashSYP = 0;
    let partnerCashUSD = 0;
    let abdallahCashSYP = 0;
    let abdallahCashUSD = 0;

    const cashTxs = this.getCashTransactions().filter((ctx) => isBeforeDate(ctx.date || ctx.createdAt));
    for (const ctx of cashTxs) {
      if (ctx.category === 'partner_withdrawal' || ctx.person === 'الشريك' || ctx.person === (settings.partnerName || 'الشريك')) {
        if (ctx.currency === 'USD') partnerCashUSD += ctx.amount;
        else partnerCashSYP += ctx.amount;
      } else if (ctx.category === 'abdallah_withdrawal' || ctx.person === 'عبدالله') {
        if (ctx.currency === 'USD') abdallahCashUSD += ctx.amount;
        else abdallahCashSYP += ctx.amount;
      }
    }

    let partnerGoodsSYP = 0;
    let partnerGoodsUSD = 0;
    let abdallahGoodsSYP = 0;
    let abdallahGoodsUSD = 0;

    const goodsW = this.getGoodsWithdrawals().filter((w) => isBeforeDate(w.date || w.createdAt));
    for (const w of goodsW) {
      if (w.person === 'partner') {
        if (w.currency === 'USD') partnerGoodsUSD += w.totalCost;
        else partnerGoodsSYP += w.totalCost;
      } else {
        if (w.currency === 'USD') abdallahGoodsUSD += w.totalCost;
        else abdallahGoodsSYP += w.totalCost;
      }
    }

    const partnerTotalWithdrawnUSD = partnerCashUSD + (partnerCashSYP / rate) + partnerGoodsUSD + (partnerGoodsSYP / rate);
    const abdallahTotalWithdrawnUSD = abdallahCashUSD + (abdallahCashSYP / rate) + abdallahGoodsUSD + (abdallahGoodsSYP / rate);
    const totalWithdrawalsUSD = partnerTotalWithdrawnUSD + abdallahTotalWithdrawnUSD;

    const partnerSummary = {
      partnerName: rawPartnerSummary.partnerName,
      totalCapitalUSD: rawPartnerSummary.totalCapitalUSD || 5000,
      partnerCashSYP,
      partnerCashUSD,
      partnerGoodsSYP,
      partnerGoodsUSD,
      partnerTotalWithdrawnUSD,
      abdallahCashSYP,
      abdallahCashUSD,
      abdallahGoodsSYP,
      abdallahGoodsUSD,
      abdallahTotalWithdrawnUSD,
    };

    // 6. Cumulative Operating Profits (Sales profit - Operating Expenses) up to asOfDate
    let cumulativeSalesProfitUSD = 0;
    const filteredInvoices = this.getInvoices().filter((inv) => isBeforeDate(inv.date));
    for (const inv of filteredInvoices) {
      const invRate = inv.exchangeRate || rate;
      const saleTotalUSD = inv.currency === 'USD' ? inv.finalTotal : (inv.finalTotal / invRate);
      let invCostUSD = 0;
      for (const item of inv.items) {
        const prod = products.find((p) => p.id === item.productId);
        const ppc = prod?.piecesPerCarton || 1;
        const totalP = (item.cartons * ppc) + item.pieces;
        const itemUnitCost = prod?.purchaseCost || 0;
        const itemCostCurrency = prod?.costCurrency || 'SYP';
        const lineCostOriginal = (totalP / ppc) * itemUnitCost;
        const lineCostUSD = itemCostCurrency === 'USD' ? lineCostOriginal : (lineCostOriginal / invRate);
        invCostUSD += lineCostUSD;
      }
      cumulativeSalesProfitUSD += (saleTotalUSD - invCostUSD);
    }

    let operatingExpensesUSD = 0;
    const filteredExpenses = this.getExpenses().filter((exp) => isBeforeDate(exp.date));
    for (const exp of filteredExpenses) {
      if (exp.currency === 'USD') operatingExpensesUSD += exp.amount;
      else operatingExpensesUSD += (exp.amount / rate);
    }
    const operatingProfitUSD = cumulativeSalesProfitUSD - operatingExpensesUSD;

    // 7. Net Project Value / Equity
    // Total Assets = Cash (in USD) + Customer Debts (in USD) + Inventory Value (in USD)
    const cashTotalInUSD = cashUSD + (cashSYP / rate);
    const customerDebtsInUSD = customerDebtUSD + (customerDebtSYP / rate);
    const totalAssetsUSD = cashTotalInUSD + customerDebtsInUSD + totalInventoryInUSD;

    // Total Liabilities = Supplier Debts (in USD)
    const supplierDebtsInUSD = supplierDebtUSD + (supplierDebtSYP / rate);
    const totalLiabilitiesUSD = supplierDebtsInUSD;

    // Net Equity (الصافي الفعلي للمشروع)
    const netProjectWorthUSD = totalAssetsUSD - totalLiabilitiesUSD;
    const netProjectWorthSYP = netProjectWorthUSD * rate;

    // Capital & Profit Comparison
    const initialCapitalUSD = partnerSummary.totalCapitalUSD || 5000;
    const netProjectPlusWithdrawalsUSD = netProjectWorthUSD + totalWithdrawalsUSD;
    const netProfitOrLossUSD = netProjectPlusWithdrawalsUSD - initialCapitalUSD;

    // 8. Strict Project Matching & Reconciliation (المطابقة المحاسبية)
    // Assets = Liabilities + Equity
    // Theoretical Equity = Initial Capital + Operating Profits - Total Withdrawals
    const expectedEquityUSD = initialCapitalUSD + operatingProfitUSD - totalWithdrawalsUSD;
    const rawDiff = netProjectWorthUSD - expectedEquityUSD;
    const unexplainedDifferenceUSD = Math.abs(rawDiff) < 0.05 ? 0 : Number(rawDiff.toFixed(2));
    const isBalanced = unexplainedDifferenceUSD === 0;

    const reconciliation: ProjectReconciliation = {
      totalAssetsUSD,
      totalLiabilitiesUSD,
      actualNetWorthUSD: netProjectWorthUSD,
      initialCapitalUSD,
      operatingProfitUSD,
      partnerTotalWithdrawnUSD,
      abdallahTotalWithdrawnUSD,
      totalWithdrawalsUSD,
      expectedEquityUSD,
      unexplainedDifferenceUSD,
      isBalanced,
    };

    return {
      timestamp: new Date().toISOString(),
      asOfDate: asOfDate || new Date().toISOString().slice(0, 10),
      exchangeRate: rate,
      // Cash
      cashSYP,
      cashUSD,
      cashTotalInUSD,
      // Customers
      customerDebtSYP,
      customerDebtUSD,
      customerDebtsInUSD,
      customerDebtsList,
      // Suppliers
      supplierDebtSYP,
      supplierDebtUSD,
      supplierDebtsInUSD,
      supplierDebtsList,
      // Inventory
      inventoryCostUSD,
      inventoryCostSYP,
      totalInventoryInUSD,
      totalInventoryInSYP,
      totalProductsCount: products.length,
      totalPiecesCount,
      inventorySYPItems,
      inventoryUSDItems,
      // Partners
      partnerSummary,
      // Final Project Balance
      totalAssetsUSD,
      totalLiabilitiesUSD,
      netProjectWorthUSD,
      netProjectWorthSYP,
      initialCapitalUSD,
      totalWithdrawalsUSD,
      netProfitOrLossUSD,
      // Reconciliation
      reconciliation,
    };
  }

  // Backup and restore
  static exportBackup(): string {
    const data = {
      version: 2,
      timestamp: new Date().toISOString(),
      settings: this.getSettings(),
      products: this.getProducts(),
      customers: this.getCustomers(),
      invoices: this.getInvoices(),
      purchaseInvoices: this.getPurchaseInvoices(),
      customerPayments: this.getCustomerPayments(),
      suppliers: this.getSuppliers(),
      supplierTransactions: this.getSupplierTransactions(),
      expenses: this.getExpenses(),
      cashTransactions: this.getCashTransactions(),
      usdPurchases: this.getUsdPurchases(),
      goodsWithdrawals: this.getGoodsWithdrawals(),
      partnerCapitals: this.getPartnerCapitals(),
    };
    return JSON.stringify(data, null, 2);
  }

  static importBackup(jsonString: string): boolean {
    try {
      const data = JSON.parse(jsonString);
      if (data.settings) this.saveSettings(data.settings);
      if (Array.isArray(data.products)) this.saveProducts(data.products);
      if (Array.isArray(data.customers)) this.saveCustomers(data.customers);
      if (Array.isArray(data.invoices)) this.saveInvoices(data.invoices);
      if (Array.isArray(data.purchaseInvoices)) this.savePurchaseInvoices(data.purchaseInvoices);
      if (Array.isArray(data.customerPayments)) this.saveCustomerPayments(data.customerPayments);
      if (Array.isArray(data.suppliers)) this.saveSuppliers(data.suppliers);
      if (Array.isArray(data.supplierTransactions)) this.saveSupplierTransactions(data.supplierTransactions);
      if (Array.isArray(data.expenses)) this.saveExpenses(data.expenses);
      if (Array.isArray(data.cashTransactions)) this.saveCashTransactions(data.cashTransactions);
      if (Array.isArray(data.usdPurchases)) this.saveUsdPurchases(data.usdPurchases);
      if (Array.isArray(data.goodsWithdrawals)) this.saveGoodsWithdrawals(data.goodsWithdrawals);
      if (Array.isArray(data.partnerCapitals)) this.savePartnerCapitals(data.partnerCapitals);
      return true;
    } catch (err) {
      console.error('Failed to import backup:', err);
      return false;
    }
  }

  static resetToDefault(): void {
    this.saveSettings(initialSettings);
    this.saveProducts(initialProducts);
    this.saveCustomers(initialCustomers);
    this.saveInvoices(initialInvoices);
    this.savePurchaseInvoices(initialPurchaseInvoices);
    this.saveCustomerPayments(initialCustomerPayments);
    this.saveSuppliers(initialSuppliers);
    this.saveSupplierTransactions(initialSupplierTransactions);
    this.saveExpenses(initialExpenses);
    this.saveCashTransactions([]);
    this.saveUsdPurchases([]);
    this.saveGoodsWithdrawals([]);
    this.savePartnerCapitals([]);
  }
}
