import { Invoice } from '../types';
import { Capacitor, registerPlugin } from '@capacitor/core';

interface NativeThermalPrinterPlugin {
  listPaired(): Promise<{ devices: Array<{ name: string; address: string }> }>;
  connect(options: { address: string }): Promise<{ success: boolean; deviceName?: string; error?: string }>;
  printRaw(options: { data: string }): Promise<{ success: boolean; error?: string }>;
  disconnect(): Promise<void>;
}

const NativeThermalPrinter = registerPlugin<NativeThermalPrinterPlugin>('ThermalPrinter');

export interface BluetoothDeviceState {
  connected: boolean;
  deviceName: string | null;
  deviceId?: string | null;
  paperWidth: '58mm' | '80mm';
  error: string | null;
}

export interface DiscoveredPrinter {
  id: string;
  name: string;
  address?: string;
  type?: 'ble' | 'spp' | 'classic';
}

// ESC/POS Commands
const ESC = 0x1b;
const GS = 0x1d;

const STORAGE_KEY_SAVED_PRINTER = 'al_ataya_last_bluetooth_printer';
const STORAGE_KEY_PAPER_WIDTH = 'al_ataya_printer_paper_width';

export class BluetoothThermalPrinter {
  private static device: any = null;
  private static server: any = null;
  private static characteristic: any = null;
  private static isConnectedState = false;
  private static currentDeviceName: string | null = null;
  private static currentDeviceId: string | null = null;

  static isWebBluetoothSupported(): boolean {
    return typeof navigator !== 'undefined' && 'bluetooth' in navigator;
  }

  static isWebBluetoothBlockedByPolicy(): boolean {
    try {
      if (typeof window !== 'undefined' && window.self !== window.top) {
        // Embedded in an iframe: Permissions policy blocks bluetooth in almost all web containers
        return true;
      }
      if (typeof document !== 'undefined') {
        const docAny = document as any;
        if (docAny.permissionsPolicy && typeof docAny.permissionsPolicy.allowsFeature === 'function') {
          return !docAny.permissionsPolicy.allowsFeature('bluetooth');
        }
        if (docAny.featurePolicy && typeof docAny.featurePolicy.allowsFeature === 'function') {
          return !docAny.featurePolicy.allowsFeature('bluetooth');
        }
      }
    } catch {
      // ignore
    }
    return false;
  }

  static isNativeAndroid(): boolean {
    return (
      typeof window !== 'undefined' &&
      ((window as any).Capacitor !== undefined ||
        (window as any).AndroidPrinter !== undefined ||
        /Android/i.test(navigator.userAgent))
    );
  }

  static getSavedPrinter(): { id?: string; name?: string } | null {
    try {
      const saved = localStorage.getItem(STORAGE_KEY_SAVED_PRINTER);
      return saved ? JSON.parse(saved) : null;
    } catch {
      return null;
    }
  }

  static savePrinter(name?: string | null, id?: string | null) {
    try {
      if (name) {
        localStorage.setItem(STORAGE_KEY_SAVED_PRINTER, JSON.stringify({ name, id: id || undefined }));
      }
    } catch {
      // ignore
    }
  }

  static getPaperWidth(): '58mm' | '80mm' {
    try {
      return (localStorage.getItem(STORAGE_KEY_PAPER_WIDTH) as '58mm' | '80mm') || '80mm';
    } catch {
      return '80mm';
    }
  }

  static setPaperWidth(width: '58mm' | '80mm') {
    try {
      localStorage.setItem(STORAGE_KEY_PAPER_WIDTH, width);
    } catch {
      // ignore
    }
  }

  static isConnected(): boolean {
    return this.isConnectedState && (Capacitor.getPlatform() === 'android' || !!this.characteristic);
  }

  static getConnectedDeviceName(): string | null {
    return this.currentDeviceName;
  }

  static async disconnect(): Promise<void> {
    try {
      if (this.server && this.server.disconnect) {
        this.server.disconnect();
      }
      if (this.device && this.device.gatt && this.device.gatt.disconnect) {
        this.device.gatt.disconnect();
      }
      if (Capacitor.getPlatform() === 'android') await NativeThermalPrinter.disconnect();
    } catch (e) {
      console.warn('Disconnect warning', e);
    } finally {
      this.device = null;
      this.server = null;
      this.characteristic = null;
      this.isConnectedState = false;
      this.currentDeviceName = null;
      this.currentDeviceId = null;
    }
  }

  /**
   * Connect to Bluetooth Thermal Printer (SPP / Bluetooth Classic / Web Bluetooth BLE)
   */
  static async connect(): Promise<{
    success: boolean;
    deviceName?: string;
    error?: string;
    isPermissionsPolicyBlocked?: boolean;
  }> {
    // 1. Real Android native SPP bridge. Generic Bluetooth Classic SPP is not Web Bluetooth.
    if (Capacitor.getPlatform() === 'android') {
      try {
        const paired = await NativeThermalPrinter.listPaired();
        const saved = this.getSavedPrinter();
        const selected = saved?.id
          ? paired.devices.find((d) => d.address === saved.id)
          : paired.devices[0];
        if (!selected) return { success: false, error: 'لا توجد طابعة مقترنة. قم بإقران الطابعة من إعدادات Bluetooth في الهاتف أولاً.' };
        const res = await NativeThermalPrinter.connect({ address: selected.address });
        if (res.success) {
          this.isConnectedState = true;
          this.currentDeviceName = res.deviceName || selected.name || 'طابعة حرارية';
          this.currentDeviceId = selected.address;
          this.savePrinter(this.currentDeviceName, selected.address);
          return { success: true, deviceName: this.currentDeviceName };
        }
        return { success: false, error: res.error || 'تعذر الاتصال بالطابعة.' };
      } catch (err: any) {
        return { success: false, error: err?.message || 'تعذر الوصول إلى Bluetooth في Android.' };
      }
    }

    // 2. Check if running inside an iframe or blocked by browser permissions policy
    if (this.isWebBluetoothBlockedByPolicy()) {
      return {
        success: false,
        isPermissionsPolicyBlocked: true,
        error:
          'سياسة المتصفح تمنع الاتصال المباشر بالبلوتوث من داخل نافذة العرض المضمنة (Permissions Policy). تم توفير خيارات الطباعة المتوافقة.',
      };
    }

    // 3. Web Bluetooth standard connect
    if (!this.isWebBluetoothSupported()) {
      return {
        success: false,
        error:
          'ميزة البلوتوث اللاسلكي غير مفعلة في هذا المتصفح. يمكنك استخدام زر الطباعة الحرارية أو تطبيق RawBT.',
      };
    }

    try {
      const device = await (navigator as any).bluetooth.requestDevice({
        acceptAllDevices: true,
        optionalServices: [
          '000018f0-0000-1000-8000-00805f9b34fb', // Standard Printer
          '0000ffe0-0000-1000-8000-00805f9b34fb', // HM-10 / Common Chinese 58/80mm
          '49535343-fe7d-4ae5-8fa9-9fafd205e455', // ISSC
          'e7810a71-73ae-499d-8c15-faa9aef0c3f2', // Pos
          '00001101-0000-1000-8000-00805f9b34fb', // Serial Port Profile (SPP)
        ],
      });

      this.device = device;
      this.currentDeviceId = device.id;
      const server = await device.gatt.connect();
      this.server = server;

      const services = await server.getPrimaryServices();
      let writeChar: any = null;

      for (const service of services) {
        try {
          const chars = await service.getCharacteristics();
          for (const char of chars) {
            if (char.properties.write || char.properties.writeWithoutResponse) {
              writeChar = char;
              break;
            }
          }
          if (writeChar) break;
        } catch {
          // continue
        }
      }

      if (!writeChar) {
        return {
          success: false,
          error: 'تم الاقتران ولكن لم يتم العثور على قناة كتابة ESC/POS متوافقة في الطابعة.',
        };
      }

      this.characteristic = writeChar;
      this.isConnectedState = true;
      this.currentDeviceName = device.name || 'طابعة حرارية بلوتوث';
      this.savePrinter(this.currentDeviceName, device.id);

      return { success: true, deviceName: this.currentDeviceName || undefined };
    } catch (err: any) {
      console.warn('Bluetooth connect warning:', err);
      const isPolicyBlocked =
        err?.message &&
        (err.message.toLowerCase().includes('permissions policy') ||
          err.message.toLowerCase().includes('disallowed') ||
          err.name === 'SecurityError');

      return {
        success: false,
        isPermissionsPolicyBlocked: isPolicyBlocked,
        error: isPolicyBlocked
          ? 'المتصفح يمنع الاتصال المباشر بالبلوتوث من داخل نافذة العرض (Permissions Policy).'
          : err?.message || 'تم إلغاء اختيار الطابعة أو لم يتم العثور على أجهزة قريبة.',
      };
    }
  }

  /**
   * Send Raw ESC/POS bytes to the printer (with chunking for BLE MTU limit)
   */
  static async sendBytes(data: Uint8Array): Promise<boolean> {
    // 1. Android Native SPP bridge
    if (Capacitor.getPlatform() === 'android') {
      try {
        let binary = '';
        const chunk = 0x8000;
        for (let i = 0; i < data.length; i += chunk) binary += String.fromCharCode(...data.subarray(i, i + chunk));
        const base64 = btoa(binary);
        const res = await NativeThermalPrinter.printRaw({ data: base64 });
        return !!res.success;
      } catch (e) {
        console.error('Native thermal printer error:', e);
        return false;
      }
    }

    // 2. Web Bluetooth BLE fallback
    if (this.characteristic) {
      try {
        const chunkSize = 100;
        for (let i = 0; i < data.length; i += chunkSize) {
          const chunk = data.slice(i, i + chunkSize);
          await this.characteristic.writeValue(chunk);
        }
        return true;
      } catch (err) {
        console.error('Failed to send bluetooth print command:', err);
      }
    }

    return false;
  }

  /**
   * Test Print (طباعة اختبار)
   */
  static async printTestReceipt(centerName = 'مركز العطايا لتوزيع المواد الغذائية'): Promise<boolean> {
    const encoder = new TextEncoder();
    const parts: number[] = [];

    parts.push(ESC, 0x40); // Initialize
    parts.push(ESC, 0x61, 0x01); // Center
    parts.push(ESC, 0x21, 0x20); // Double size
    parts.push(...Array.from(encoder.encode(centerName + '\n')));

    parts.push(ESC, 0x21, 0x00); // Normal
    parts.push(...Array.from(encoder.encode('--------------------------------\n')));
    parts.push(...Array.from(encoder.encode('** فحص اتصال الطابعة الحرارية **\n')));
    parts.push(...Array.from(encoder.encode(`التاريخ: ${new Date().toLocaleDateString('ar-SY')}\n`)));
    parts.push(...Array.from(encoder.encode('حالة الاتصال: متصل وجاهز بنجاح ✓\n')));
    parts.push(...Array.from(encoder.encode('--------------------------------\n')));
    parts.push(...Array.from(encoder.encode('مركز العطايا - نظام التوزيع\n\n\n')));
    parts.push(GS, 0x56, 0x42, 0x00); // Cut paper

    return await this.sendBytes(new Uint8Array(parts));
  }

  /**
   * Builds the ESC/POS binary byte stream for the sales invoice
   */
  static buildInvoiceEscPosBytes(
    invoice: Invoice,
    centerName = 'مركز العطايا لتوزيع المواد الغذائية',
    paperWidth: '58mm' | '80mm' = '80mm'
  ): Uint8Array {
    const encoder = new TextEncoder();
    const parts: number[] = [];
    const divider = paperWidth === '58mm' ? '------------------------\n' : '--------------------------------\n';
    const dblDivider = paperWidth === '58mm' ? '========================\n' : '================================\n';

    // Initialize printer
    parts.push(ESC, 0x40);
    parts.push(ESC, 0x61, 0x01); // Center
    parts.push(ESC, 0x21, 0x20); // Double size

    // Header
    parts.push(...Array.from(encoder.encode(centerName + '\n')));

    parts.push(ESC, 0x21, 0x00); // Normal
    parts.push(...Array.from(encoder.encode(divider)));

    // Invoice info
    parts.push(ESC, 0x61, 0x00); // Left/Normal
    const dateFormatted = new Date(invoice.date).toLocaleString('ar-SY', {
      year: 'numeric',
      month: '2-digit',
      day: '2-digit',
      hour: '2-digit',
      minute: '2-digit',
    });

    parts.push(...Array.from(encoder.encode(`فاتورة رقم: ${invoice.invoiceNumber}\n`)));
    parts.push(...Array.from(encoder.encode(`التاريخ: ${dateFormatted}\n`)));
    parts.push(...Array.from(encoder.encode(`العميل: ${invoice.customerName}\n`)));
    if (invoice.customerShop) {
      parts.push(...Array.from(encoder.encode(`المحل: ${invoice.customerShop}\n`)));
    }
    parts.push(...Array.from(encoder.encode(dblDivider)));

    // Items
    for (const item of invoice.items) {
      const qtyStr =
        item.pieces > 0
          ? `${item.cartons} ك و ${item.pieces} ق`
          : `${item.cartons} ${item.unit}`;

      const line = `${item.productName}\n  ${qtyStr} x ${item.unitPrice.toLocaleString('en-US')} = ${item.itemTotal.toLocaleString('en-US')} ${invoice.currency}\n`;
      parts.push(...Array.from(encoder.encode(line)));
    }

    parts.push(...Array.from(encoder.encode(dblDivider)));
    parts.push(ESC, 0x61, 0x02); // Right align

    // Previous balance and cumulative remaining debt
    const prevBalance = invoice.previousCustomerBalance || 0;
    const finalRemaining = prevBalance + invoice.finalTotal - invoice.paidAmount;

    if (prevBalance > 0) {
      parts.push(...Array.from(encoder.encode(`الرصيد السابق: ${prevBalance.toLocaleString('en-US')} ${invoice.currency}\n`)));
    }
    parts.push(...Array.from(encoder.encode(`قيمة الفاتورة: ${invoice.finalTotal.toLocaleString('en-US')} ${invoice.currency}\n`)));
    if (invoice.discount > 0) {
      parts.push(...Array.from(encoder.encode(`الخصم: ${invoice.discount.toLocaleString('en-US')} ${invoice.currency}\n`)));
    }
    parts.push(...Array.from(encoder.encode(`المدفوع: ${invoice.paidAmount.toLocaleString('en-US')} ${invoice.currency}\n`)));
    parts.push(...Array.from(encoder.encode(divider)));
    parts.push(...Array.from(encoder.encode(`المتبقي: ${finalRemaining.toLocaleString('en-US')} ${invoice.currency}\n`)));

    // Footer
    parts.push(ESC, 0x61, 0x01); // Center
    parts.push(...Array.from(encoder.encode('\nشكراً لتعاملكم معنا\n\n\n')));
    parts.push(GS, 0x56, 0x42, 0x00); // Cut paper

    return new Uint8Array(parts);
  }

  /**
   * Print directly via RawBT helper application on Android / Mobile POS
   */
  static printViaRawBT(
    invoice: Invoice,
    centerName = 'مركز العطايا لتوزيع المواد الغذائية',
    paperWidth: '58mm' | '80mm' = '80mm'
  ): boolean {
    try {
      const bytes = this.buildInvoiceEscPosBytes(invoice, centerName, paperWidth);
      let binary = '';
      for (let i = 0; i < bytes.byteLength; i++) {
        binary += String.fromCharCode(bytes[i]);
      }
      const base64 = window.btoa(binary);

      const rawbtUrl = `rawbt:data:application/octet-stream;base64,${base64}`;
      const link = document.createElement('a');
      link.href = rawbtUrl;
      link.style.display = 'none';
      document.body.appendChild(link);
      link.click();
      setTimeout(() => {
        if (document.body.contains(link)) document.body.removeChild(link);
      }, 1000);
      return true;
    } catch (e) {
      console.error('RawBT launch error:', e);
      return false;
    }
  }

  /**
   * Print full sales invoice
   */
  static async printInvoice(
    invoice: Invoice,
    centerName = 'مركز العطايا لتوزيع المواد الغذائية',
    paperWidth: '58mm' | '80mm' = '80mm'
  ): Promise<boolean> {
    const bytes = this.buildInvoiceEscPosBytes(invoice, centerName, paperWidth);
    return await this.sendBytes(bytes);
  }
}
