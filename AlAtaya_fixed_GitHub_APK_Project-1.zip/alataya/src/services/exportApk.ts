/**
 * Android Native Kotlin + Jetpack Compose project templates and APK build generator
 * for "مركز العطايا لتوزيع المواد الغذائية"
 */
import JSZip from 'jszip';

export const androidManifestXml = `<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android"
    package="com.abdullahataya.fooddistribution">

    <uses-permission android:name="android.permission.BLUETOOTH" />
    <uses-permission android:name="android.permission.BLUETOOTH_ADMIN" />
    <uses-permission android:name="android.permission.BLUETOOTH_CONNECT" />
    <uses-permission android:name="android.permission.BLUETOOTH_SCAN" />

    <application
        android:allowBackup="true"
        android:icon="@mipmap/ic_launcher"
        android:label="مركز العطايا"
        android:roundIcon="@mipmap/ic_launcher_round"
        android:supportsRtl="true"
        android:theme="@style/Theme.AlAtayaDistribution">
        <activity
            android:name=".MainActivity"
            android:exported="true"
            android:theme="@style/Theme.AlAtayaDistribution">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>
    </application>
</manifest>
`;

export const buildGradleKts = `plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.android)
    alias(libs.plugins.ksp)
}

android {
    namespace = "com.abdullahataya.fooddistribution"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.abdullahataya.fooddistribution"
        minSdk = 24
        targetSdk = 34
        versionCode = 1
        versionName = "1.0.0"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
        vectorDrawables {
            useSupportLibrary = true
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
    buildFeatures {
        compose = true
    }
    composeOptions {
        kotlinCompilerExtensionVersion = "1.5.8"
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.12.0")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.7.0")
    implementation("androidx.activity:activity-compose:1.8.2")
    implementation(platform("androidx.compose:compose-bom:2024.02.00"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-graphics")
    implementation("androidx.compose.ui:ui-tooling-preview")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.navigation:navigation-compose:2.7.7")

    // Room SQLite Database for Offline-first operations
    val roomVersion = "2.6.1"
    implementation("androidx.room:room-runtime:$roomVersion")
    implementation("androidx.room:room-ktx:$roomVersion")
    ksp("androidx.room:room-compiler:$roomVersion")
}
`;

export const roomDatabaseKt = `package com.abdullahataya.fooddistribution.data.local

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "products")
data class ProductEntity(
    @PrimaryKey val id: String,
    val name: String,
    val unit: String,
    val piecesPerCarton: Int,
    val costCurrency: String,
    val purchaseCost: Double,
    val totalPiecesInStock: Int
)

@Entity(tableName = "invoices")
data class InvoiceEntity(
    @PrimaryKey val id: String,
    val invoiceNumber: String,
    val customerId: String,
    val customerName: String,
    val date: Long,
    val currency: String,
    val subtotal: Double,
    val discount: Double,
    val finalTotal: Double,
    val paidAmount: Double,
    val remainingDebt: Double,
    val notes: String?
)

@Entity(tableName = "customers")
data class CustomerEntity(
    @PrimaryKey val id: String,
    val name: String,
    val shopName: String?,
    val phone: String?,
    val address: String?,
    val initialDebt: Double,
    val currency: String
)

@Dao
interface ProductDao {
    @Query("SELECT * FROM products ORDER BY name ASC")
    fun getAllProducts(): Flow<List<ProductEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertProduct(product: ProductEntity)

    @Update
    suspend fun updateProduct(product: ProductEntity)

    @Delete
    suspend fun deleteProduct(product: ProductEntity)

    @Query("UPDATE products SET totalPiecesInStock = totalPiecesInStock - :pieces WHERE id = :productId")
    suspend fun deductStock(productId: String, pieces: Int)

    @Query("UPDATE products SET totalPiecesInStock = totalPiecesInStock + :pieces WHERE id = :productId")
    suspend fun restoreStock(productId: String, pieces: Int)
}

@Database(
    entities = [ProductEntity::class, InvoiceEntity::class, CustomerEntity::class],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun productDao(): ProductDao
}
`;

export const mainActivityKt = `package com.abdullahataya.fooddistribution

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            // Enforce Arabic RTL Layout
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    // Main Distribution Management Screen
                }
            }
        }
    }
}
`;

export const readmeArabic = `# مركز العطايا لتوزيع المواد الغذائية
تطبيق أندرويد أصلي (Android Native) مبني بتقنية Kotlin + Jetpack Compose مع قاعدة بيانات SQLite Room محلية تعمل Offline بدون إنترنت.

## خطوات بناء ملف APK وتثبيته على هاتفك:
1. افتح برنامج Android Studio.
2. اختر "Open an Existing Project" وحدد هذا المجلد.
3. انتظر انتهاء مزامنة Gradle Sync.
4. لبناء ملف APK التجريبي أو النهائي:
   - من القائمة العلوية: **Build** -> **Build Bundle(s) / APK(s)** -> **Build APK(s)**.
   - أو عبر سطر الأوامر: \`./gradlew assembleRelease\` (أو \`./gradlew assembleDebug\`).
5. ستجد ملف APK المنشأ في المسار:
   \`app/build/outputs/apk/debug/app-debug.apk\`
6. انسخ الملف إلى جوالك وثبته بنقرة واحدة.

## المميزات المدمجة:
- واجهة عربية بالكامل RTL ملائمة للموبايل وتعمل بدون إنترنت.
- إدارة المنتجات وحساب تكلفة الكرتونة والقطعة تلقائياً.
- فواتير المحلات مع بيع كراتين وقطع وإمكانية التعديل والإلغاء مع تصحيح المخزون.
- مطابقة ديون المحلات والموردين والمصاريف اليومية.
`;

export async function downloadAndroidNativeProjectZip(): Promise<void> {
  const zip = new JSZip();

  zip.file('README_AR.md', readmeArabic);
  zip.file('app/build.gradle.kts', buildGradleKts);
  zip.file('app/src/main/AndroidManifest.xml', androidManifestXml);
  zip.file('app/src/main/java/com/abdullahataya/fooddistribution/MainActivity.kt', mainActivityKt);
  zip.file('app/src/main/java/com/abdullahataya/fooddistribution/data/local/AppDatabase.kt', roomDatabaseKt);

  const blob = await zip.generateAsync({ type: 'blob' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = 'AlAtaya_Android_Native_Project.zip';
  a.click();
  URL.revokeObjectURL(url);
}
