package com.abdullahataya.fooddistribution;

import android.Manifest;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.pm.PackageManager;
import android.util.Base64;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.annotation.CapacitorPlugin;
import com.getcapacitor.annotation.Permission;
import com.getcapacitor.PluginMethod;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

@CapacitorPlugin(
    name = "ThermalPrinter",
    permissions = {
        @Permission(alias = "bluetoothConnect", strings = { Manifest.permission.BLUETOOTH_CONNECT }),
        @Permission(alias = "bluetoothScan", strings = { Manifest.permission.BLUETOOTH_SCAN })
    }
)
public class ThermalPrinterPlugin extends Plugin {
    private BluetoothSocket socket;
    private OutputStream output;
    private BluetoothDevice device;
    private static final UUID SPP_UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");

    @PluginMethod
    public void listPaired(PluginCall call) {
        if (!hasPermission(Manifest.permission.BLUETOOTH_CONNECT)) {
            call.reject("صلاحية Bluetooth غير ممنوحة. اسمح للتطبيق بالوصول إلى الأجهزة القريبة من إعدادات Android.");
            return;
        }
        try {
            BluetoothAdapter adapter = BluetoothAdapter.getDefaultAdapter();
            if (adapter == null) { call.reject("Bluetooth غير متوفر على هذا الهاتف"); return; }
            List<JSObject> list = new ArrayList<>();
            for (BluetoothDevice d : adapter.getBondedDevices()) {
                JSObject item = new JSObject();
                item.put("name", d.getName() == null ? "Bluetooth Printer" : d.getName());
                item.put("address", d.getAddress());
                list.add(item);
            }
            JSObject out = new JSObject();
            out.put("devices", list);
            call.resolve(out);
        } catch (Exception e) { call.reject(e.getMessage(), e); }
    }

    @PluginMethod
    public void connect(PluginCall call) {
        if (!hasPermission(Manifest.permission.BLUETOOTH_CONNECT)) {
            call.reject("صلاحية Bluetooth غير ممنوحة. اسمح للتطبيق بالوصول إلى الأجهزة القريبة من إعدادات Android.");
            return;
        }
        String address = call.getString("address");
        if (address == null || address.isEmpty()) { call.reject("عنوان الطابعة غير محدد"); return; }
        try {
            BluetoothAdapter adapter = BluetoothAdapter.getDefaultAdapter();
            if (adapter == null) { call.reject("Bluetooth غير متوفر"); return; }
            disconnectInternal();
            device = adapter.getRemoteDevice(address);
            adapter.cancelDiscovery();
            socket = device.createRfcommSocketToServiceRecord(SPP_UUID);
            socket.connect();
            output = socket.getOutputStream();
            JSObject out = new JSObject();
            out.put("success", true);
            out.put("deviceName", device.getName() == null ? "طابعة حرارية" : device.getName());
            call.resolve(out);
        } catch (Exception e) {
            disconnectInternal();
            call.reject("تعذر الاتصال بالطابعة: " + e.getMessage(), e);
        }
    }

    @PluginMethod
    public void printRaw(PluginCall call) {
        if (output == null) { call.reject("لا توجد طابعة متصلة"); return; }
        String data = call.getString("data");
        if (data == null) { call.reject("بيانات الطباعة مفقودة"); return; }
        try {
            byte[] bytes = Base64.decode(data, Base64.DEFAULT);
            output.write(bytes);
            output.flush();
            JSObject out = new JSObject(); out.put("success", true); call.resolve(out);
        } catch (Exception e) { call.reject("فشل إرسال بيانات الطباعة: " + e.getMessage(), e); }
    }

    @PluginMethod
    public void disconnect(PluginCall call) { disconnectInternal(); call.resolve(); }

    private void disconnectInternal() {
        try { if (output != null) output.close(); } catch (Exception ignored) {}
        try { if (socket != null) socket.close(); } catch (Exception ignored) {}
        output = null; socket = null; device = null;
    }
}
